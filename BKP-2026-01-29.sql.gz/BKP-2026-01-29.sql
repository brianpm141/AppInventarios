/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: accessories
# ------------------------------------------------------------

INSERT INTO
  `accessories` (
    `id`,
    `brand`,
    `product_name`,
    `total`,
    `category_id`,
    `details`,
    `status`
  )
VALUES
  (1, 'HP', 'Toner 4567', 0, 7, '', 0),(2, 'Samsung', 'Imagen', 5, 7, '', 0),(3, 'Samsung', 'Fusor 5433', 1, 7, '', 0),(4, 'TK-1175 KYOCERA', 'TONER KIT BLACK', 3, 7, '', 1),(5, 'TK-3402 KYOCERA', 'TONER KIT BLACK', 1, 7, '', 1),(6, 'TK-3402', 'TONER KIT MAGNETA', 1, 7, '', 1),(7, 'TK-5372Y', 'TONER KIT YELLOW', 2, 7, '', 1),(8, 'TK-5372C', 'TONER KIT CIAN', 1, 7, '', 1),(9, 'TK-5372K', 'TONER KIT BLACK', 2, 7, '', 1),(10, 'TK-3432', 'TONER KIT BLACK', 2, 7, '', 1),(11, '303E SAMSUNG', 'TONER BLACK', 4, 7, '', 1),(12, 'JC91-01023A ', 'FUSOR', 1, 7, '', 1),(13, 'MLT-D203U SAMSUNG', 'TONER', 1, 7, '', 1),(14, 'MLT-D201L SAMSUNG', 'TONER', 1, 7, '', 1),(
    15,
    'MLT-R303/SEE HP',
    'TAMBOR DE TRANSFERENCIA DE IMAGENES',
    0,
    7,
    '',
    1
  ),(16, 'MLT-D358S', 'TONER ', 1, 7, '', 1),(17, 'SILIMEX', 'ESPUMA LIMPIADORA', 5, 9, '', 1),(18, 'SILIMEX', 'LIMPIADOR DE PANTALLAS', 2, 9, '', 1),(19, 'PROLICOM', 'AIRE COMPRIMIDO', 5, 9, '', 1),(20, '3M', 'TRAPOS', 9, 9, 'ROJOS, AZULES', 1),(21, 'HILOOK IPC-T240H', 'CAMARA IP', 1, 10, '', 1),(
    22,
    'HILOOK H.265+',
    'CAMARA IP',
    5,
    10,
    '1 Cámara bloqueada',
    1
  ),(
    23,
    'Cat 5e Linkedpro',
    'RJ-45 ',
    100,
    11,
    'Conector de chapa de oro a 30 micras',
    1
  ),(24, 'SILIMEX', 'LIMPIADOR DE CIRCUITOS', 1, 9, '', 1),(
    25,
    'DIVERSEY',
    'GEL DESINFECTANTE',
    1,
    9,
    '946 ML\nCADUCIDAD: 15 FEB 2026',
    1
  ),(
    26,
    'GR Perlec',
    'BROCHAS',
    2,
    12,
    'Brocha chica y grande (rojas)',
    1
  ),(
    27,
    'VARIAS',
    'PINZAS PONCHADORAS',
    2,
    12,
    'Pinza amarilla FLUKE netwoks\nPinza verde Commercial Electric',
    1
  ),(28, 'TRUPER', 'PINZAS DE ELECTRICISTA', 1, 12, '', 1);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: areas
# ------------------------------------------------------------

INSERT INTO
  `areas` (`id`, `name`, `description`, `status`, `id_floor`)
VALUES
  (1, 'COMANDERA', 'COMANDERA', 1, 1),(2, 'CAFETERA', 'CAFETERA', 1, 1),(
    3,
    'ADMINISTRACION CAFETERIA',
    'ADMINISTRACION CAFETERIA',
    1,
    1
  ),(
    4,
    'EJECUTIVO DE VENTAS',
    'EJECUTIVO DE VENTAS',
    1,
    1
  ),(5, 'VALLET PARKING', 'VALLET PARKING', 1, 1),(7, 'COOR FARMACIA', 'COOR FARMACIA', 1, 1),(8, 'SUP FARMACIA', 'SUP FARMACIA', 1, 1),(9, 'AUX FARMACIA', 'AUX FARMACIA', 1, 1),(10, 'COOR AGR', 'COOR AGR', 1, 1),(11, 'SUPERVISOR AGR', 'SUPERVISOR AGR', 1, 1),(12, 'AUX ARG', 'AUX ARG', 1, 1),(
    13,
    'CONSULTORIO 1 URGENCIAS',
    'CONSULTORIO 1 URGENCIAS',
    1,
    1
  ),(
    14,
    'CONSULTORIO 2 URGENCIAS',
    'CONSULTORIO 2 URGENCIAS',
    1,
    1
  ),(
    15,
    'CONSULTORIO 3 URGENCIAS',
    'CONSULTORIO 3 URGENCIAS',
    1,
    1
  ),(
    16,
    'MEDICO URGENCIAS CENTRAL',
    'MEDICO URGENCIAS CENTRAL',
    1,
    1
  ),(17, 'DOCTORES URGENCIAS', 'DOCTORES URGENCIAS', 1, 1),(18, 'URGENCIAS CARGOS', 'URGENCIAS CARGOS', 1, 1),(19, 'ADMISION URGENCIAS', 'ADMISION URGENCIAS', 1, 1),(20, 'INFORMES URGENCIAS', 'INFORMES URGENCIAS', 1, 1),(21, 'CAJAS URGENCIAS', 'CAJAS URGENCIAS', 1, 1),(22, 'INHALOTERAPIA', 'INHALOTERAPIA', 1, 1),(
    23,
    'ALMACEN CORTA ESTANCIA',
    'ALMACEN CORTA ESTANCIA',
    1,
    1
  ),(24, 'CHEF', 'CHEF', 1, 1),(25, 'VIVERES', 'VIVERES', 1, 1),(26, 'NUTRICION', 'NUTRICION', 1, 1),(27, 'COOR CAJAS', 'COOR CAJAS', 1, 1),(28, 'SUPERVISOR CAJAS', 'SUPERVISOR CAJAS', 1, 1),(29, 'CAJAS 1', 'CAJAS 1', 1, 1),(30, 'CAJAS 2', 'CAJAS 2', 1, 1),(31, 'ADMISION 2', 'ADMISION 2', 1, 1),(32, 'CALIDAD', 'CALIDAD', 1, 1),(33, 'INFORMES', 'INFORMES', 1, 1),(34, 'ADMISION 1', 'ADMISION 1', 1, 1),(35, 'COOR BIOMEDICA', 'COOR BIOMEDICA', 1, 1),(36, 'ING BIOMDICO', 'ING BIOMDICO', 1, 1),(37, 'BECARIO BIOMDICA', 'BECARIO BIOMDICA', 1, 1),(
    38,
    'CENTRAL ENFERMERIA UREGNCIAS',
    'ENFERMERIA',
    1,
    1
  ),(39, 'ENLACE', 'ENLACE', 1, 1),(
    40,
    'TECNICOS RADIOLOGOS 1',
    'TECNICOS RADIOLOGOS 1',
    1,
    1
  ),(
    41,
    'TECNICOS RADIOLOGOS 2',
    'TECNICOS RADIOLOGOS 2',
    1,
    1
  ),(42, 'MEDICO RADIOLOGO', 'MEDICO RADIOLOGO', 1, 1),(43, 'MEDICO RADIOLOGO2', 'MEDICO RADIOLOGO2', 1, 1),(44, 'RAYOS X', 'RAYOS X', 1, 1),(45, 'DIR ADMINISTRACION', 'DIR ADMINISTRACION', 1, 1),(46, 'AUX ADMINISTRACION', 'AUX ADMINISTRACION', 1, 1),(47, 'UCIN', 'UCIN', 1, 2),(48, 'CUNEROS', 'CUNEROS', 1, 2),(49, 'ENCARGADO CAPTURA', 'ENCARGADO CAPTURA', 1, 2),(50, 'AUX CAPTURA 1', 'AUX CAPTURA 1', 1, 2),(51, 'AUX CAPTURA 2', 'AUX CAPTURA 2', 1, 2),(
    52,
    'ALMACEN QUIROFANO 1',
    'ALMACEN QUIROFANO 1',
    1,
    2
  ),(
    53,
    'JEFATURA DE ENFERMERIA',
    'JEFATURA DE ENFERMERIA',
    1,
    2
  ),(54, 'PROGRAMACION', 'PROGRAMACION', 1, 2),(55, 'QX MEDICOS', 'QX MEDICOS', 1, 2),(56, 'UTIA ENFERMERIA', 'UTIA ENFERMERIA', 1, 2),(57, 'UTIA MEDICOS', 'UTIA MEDICOS', 1, 2),(58, 'CEYE', 'CEYE', 1, 2),(59, 'INTENDENCIA', 'INTENDENCIA', 1, 2),(
    60,
    'SUPERVISION ENFERMERIA',
    'SUPERVISION ENFERMERIA',
    1,
    3
  ),(61, 'AUDITOR', 'AUDITOR', 1, 3),(62, 'CONTRALORÍA', 'DRA. CARMEN', 1, 3),(63, 'DIRECCION MEDICA', 'DR. GUILLEN', 1, 3),(64, 'DIRECCION GENERAL', 'DR. RUBEN', 1, 3),(65, 'EPIDEMIOLOGIA', 'EPIDEMIOLOGIA', 1, 3),(66, 'CONSULTORIO MEDICO', 'CONSULTORIO MEDICO', 1, 3),(67, 'ENFERMERIA 2', 'ENFERMERIA 2', 1, 3),(68, 'ENFERMERIA 3', 'ENFERMERIA 3', 1, 3),(69, 'ENFERMERIA 4', 'ENFERMERIA 4', 1, 3),(70, 'JEFE DE ARCHIVO', 'JEFE DE ARCHIVO', 1, 3),(71, 'COOR FINANZAS', 'COOR FINANZAS', 1, 4),(72, 'AUX PRESUPUESTOS', 'AUX PRESUPUESTOS', 1, 4),(73, 'CUENTAS POR COBRAR', 'CUENTAS POR COBRAR', 1, 4),(
    74,
    'AUX CUENTAS POR COBRAR',
    'AUX CUENTAS POR COBRAR',
    1,
    4
  ),(
    75,
    'BECARIO DE CUENTAS POR COBRAR',
    'BECARIO DE CUENTAS POR COBRAR',
    1,
    4
  ),(76, 'CUENTAS POR PAGAR', 'CUENTAS POR PAGAR', 1, 4),(78, 'BECARIO CXP', 'BECARIO CXP', 1, 4),(79, 'COOR RH', 'COOR RH', 1, 4),(
    80,
    'TALENTO HUMANO AUXILIAR 1',
    'TALENTO HUMANO AUXILIAR 1',
    1,
    4
  ),(
    81,
    'TALENTO HUMANO AUXILIAR 2',
    'TALENTO HUMANO AUXILIAR 2',
    1,
    4
  ),(82, 'COO COMPRAS', 'COO COMPRAS', 1, 4),(83, 'AUX COMPRAS 1', 'AUX COMPRAS 1', 1, 4),(84, 'AUX COMPRAS 2', 'AUX COMPRAS 2', 1, 4),(85, 'COOR SISTEMAS', 'COOR SISTEMAS', 1, 4),(86, 'ING. SISTEMAS1', 'ING. SISTEMAS1', 1, 4),(87, 'ING SISTEMAS 2', 'ING SISTEMAS 2', 1, 4),(88, 'BECARIO SISTEMAS', 'BECARIO SISTEMAS', 1, 4),(89, 'PRESTAMO', 'PRESTAMO', 1, 4),(
    90,
    'EQUIPO DE RESGUARDO',
    'EQUIPO DE RESGUARDO',
    1,
    4
  ),(92, 'MIP 1', 'MIP 1', 1, 4),(93, 'MIP 2', 'MIP 2', 1, 4),(94, 'MIP 3', 'MIP 3', 1, 4),(95, 'MIP 4', 'MIP 4', 1, 4),(96, 'BANCO SANGRE', 'BANCO SANGRE', 1, 5),(97, 'ARCHIVO CLINICO', 'ARCHIVO CLINICO', 1, 5),(98, 'COOR MANTENIMIENTO', 'COOR MANTENIMIENTO', 1, 4),(99, 'BECARIO1', 'BECARIO1', 0, 6),(100, 'BECARIO2', 'BECARIO2', 0, 6),(101, 'ROPERIA', 'ROPERIA', 1, 6),(102, 'SITE', 'Ubicacion del MDF', 1, 1),(
    103,
    'DESCANSO MEDICOS',
    'Dentro de quirofano, area de descanso de medicos',
    1,
    2
  );
INSERT INTO
  `areas` (`id`, `name`, `description`, `status`, `id_floor`)
VALUES
  (104, 'MANTENIMIENTO', 'AUX. MANTENIMIENTO', 1, 6),(105, 'PASILLO UTIA', 'Pasillo de UTIA y CEYE', 1, 2),(
    106,
    'CENTRAL HOSPITALIZACION',
    'CENTRAL DE MEDICOS DE HOSPITALIZACION PISO 2',
    1,
    3
  ),(
    107,
    'HOSPITALIZACION SUR',
    'HOSPITALIZACION ALA SUR',
    1,
    3
  ),(
    108,
    'HOSPITALIZACION NORTE',
    'HOSPITALIZACION ALA NORTE',
    1,
    3
  ),(109, 'GOBIERNO P3', 'GOBIERNO PISO 3', 1, 4),(110, 'CAPILLA', 'CAPILLA', 1, 4),(111, 'CHECADOR', 'ENTRADA DE EMPLEADOS', 1, 1),(
    112,
    'SALON DE USOS MULTIPLES',
    'SALA DE USOS MULTIPLES',
    1,
    1
  ),(113, 'BIOMEDICA', 'AREA DE BIOMEDICA', 1, 1),(
    114,
    'SALA DE ESPERA P2',
    'AREA FUERA DE HOSPITALIZACION',
    1,
    3
  ),(115, 'LOBBY', 'EMTRADA PRINCIPAL DEL HOSPITAL', 1, 1),(116, 'GOBIERNO', 'GOBIERNO PISO 2', 1, 3);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backup_config
# ------------------------------------------------------------

INSERT INTO
  `backup_config` (
    `id`,
    `tipo`,
    `dia_semana`,
    `dia_mes`,
    `mes_anual`,
    `hora`,
    `ultimo_respaldo`,
    `status`
  )
VALUES
  (1, 'diario', NULL, NULL, NULL, '22:30:00', NULL, 0),(
    2,
    'diario',
    NULL,
    NULL,
    NULL,
    '10:00:00',
    '2025-08-08 16:00:00',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: baja_documentos
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: bajas
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: categories
# ------------------------------------------------------------

INSERT INTO
  `categories` (`id`, `name`, `description`, `type`, `status`)
VALUES
  (1, 'Desktop', 'Computadora de escritorio', 0, 1),(2, 'Laptop', 'Computadora portatil', 0, 1),(
    3,
    'All in One',
    'Computadora de escritorio todo en uno',
    0,
    1
  ),(4, 'Teclado', 'Periferico de entrada', 0, 1),(5, 'Mouse', 'Periferico de entrada', 0, 1),(6, 'Monitor', 'Periferico de salida', 0, 1),(
    7,
    'Consumibles',
    'Tóner, unidad de imagen, fusor',
    1,
    1
  ),(
    8,
    'KIT MOUSE Y TECLADO',
    'MOUSE Y TECLADO A UN MISMO USB',
    0,
    1
  ),(9, 'Mantenimiento ', 'Latas, trapos', 1, 1),(10, 'Cámaras', 'Cámara de video', 1, 1),(11, 'Insumos', 'Paquetes de piezas', 1, 1),(12, 'Herramientas', 'Herramientas varias', 1, 1),(13, 'AP', 'Access point', 0, 1);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: custom_fields
# ------------------------------------------------------------

INSERT INTO
  `custom_fields` (
    `id`,
    `name`,
    `data_type`,
    `category_id`,
    `required`,
    `status`
  )
VALUES
  (1, 'IP', 'text', 1, 0, 1),(2, 'DISCO', 'text', 1, 0, 1),(4, 'MEMORIA', 'text', 1, 0, 1),(5, 'PROCESADOR', 'text', 1, 0, 1),(7, 'DISCO', 'text', 2, 0, 1),(8, 'PROCESADOR', 'text', 2, 0, 1),(9, 'RAM', 'text', 2, 0, 1),(10, 'IP', 'text', 3, 0, 1),(11, 'DISCO', 'text', 3, 0, 1),(12, 'PROCESADOR', 'text', 3, 0, 1),(13, 'MEMORIA', 'text', 3, 0, 1),(14, 'MAC', 'text', 13, 1, 1),(15, 'DEVICE KEY', 'text', 13, 0, 1),(16, 'PUERTO', 'text', 13, 0, 1);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: departments
# ------------------------------------------------------------

INSERT INTO
  `departments` (
    `id`,
    `name`,
    `abbreviation`,
    `description`,
    `department_head`,
    `status`
  )
VALUES
  (1, 'CAFETERA', 'CAF', 'CAFETERA', 'Sin Asignar', 1),(
    2,
    'ADMINISTRACION CAFETERIA',
    'ADMC',
    'ADMINISTRACION CAFETERIA',
    'Sin Asignar',
    1
  ),(
    3,
    'EJECUTIVO DE VENTAS',
    'EJV',
    'EJECUTIVO DE VENTAS',
    'Sin Asignar',
    1
  ),(
    4,
    'VALLET PARKING',
    'VALP',
    'VALLET PARKING',
    'Sin Asignar',
    1
  ),(5, 'FARMACIA', 'FARM', 'FARMACIA', 'Sin Asignar', 1),(
    6,
    'ALMACEN GENERAL',
    'ALG',
    'ALMACEN GENERAL',
    'Sin Asignar',
    1
  ),(7, 'URGENCIAS', 'URG', 'URGENCIAS', 'Sin Asignar', 1),(
    8,
    'INHALOTERAPIA',
    'INA',
    'INHALOTERAPIA',
    'Sin Asignar',
    1
  ),(
    9,
    'CORTA ESTANCIA',
    'CORT',
    'CORTA ESTANCIA',
    'Sin Asignar',
    1
  ),(10, 'COCINA', 'COC', 'COCINA', 'Sin Asignar', 1),(11, 'NUTRICION', 'NUT', 'NUTRICION', 'Sin Asignar', 1),(12, 'CAJAS', 'CAJ', 'CAJAS', 'Sin Asignar', 1),(13, 'ADMISION', 'ADM', 'ADMISION', 'Sin Asignar', 1),(
    14,
    'BIOMEDICA',
    'BIOM',
    'BIOMEDICA',
    'Sin Asignar',
    1
  ),(
    15,
    'HEMODINAMIA',
    'HEM',
    'HEMODINAMIA',
    'Sin Asignar',
    1
  ),(
    16,
    'IMAGENOLOGIA',
    'IMG',
    'IMAGENOLOGIA',
    'Sin Asignar',
    1
  ),(
    17,
    'DIRECCION ADMINISTRATIVA',
    'DIRA',
    'DIRECCION ADMINISTRATIVA',
    'Sin Asignar',
    1
  ),(18, 'UCIN', 'CUID', 'UCIN', 'Sin Asignar', 1),(19, 'CUNEROS', 'CUN', 'CUNEROS', 'Sin Asignar', 1),(20, 'CAPTURA', 'CAPT', 'CAPTURA', 'Sin Asignar', 1),(
    21,
    'QUIROFANOS',
    'QX',
    'QUIROFANOS',
    'Sin Asignar',
    1
  ),(22, 'UTIA', 'TERA', 'UTIA', 'Sin Asignar', 1),(23, 'CEYE', 'CEYE', 'CEYE', 'Sin Asignar', 1),(24, 'HIGIENE', 'HIG', 'HIGIENE', 'Sin Asignar', 1),(
    25,
    'SUPERVISION ENFERMERIA',
    'SUPE',
    'SUPERVISION ENFERMERIA',
    'Sin Asignar',
    1
  ),(
    26,
    'CONTRALORIA',
    'CONT',
    'CONTRALORIA',
    'Sin Asignar',
    1
  ),(
    27,
    'COOR MEDICO',
    'COOR',
    'COOR MEDICO',
    'Sin Asignar',
    1
  ),(
    28,
    'DIRECCION GENERAL',
    'DIRG',
    'DIRECCION GENERAL',
    'Sin Asignar',
    1
  ),(
    29,
    'HOSPITALIZACION',
    'HOSP',
    'HOSPITALIZACION',
    'Sin Asignar',
    1
  ),(
    30,
    'ARCHIVO CLINICO',
    'ARCH',
    'ARCHIVO CLINICO',
    'Sin Asignar',
    1
  ),(
    32,
    'TALENTO HUMANO',
    'TH',
    'RECURSOS HUMANOS',
    'Sin Asignar',
    1
  ),(33, 'COMPRAS', 'COMP', 'COMPRAS', 'Sin Asignar', 1),(34, 'SISTEMAS', 'SIS', 'SISTEMAS', 'Sin Asignar', 1),(35, 'MIP', 'MIP', 'MIP', 'Sin Asignar', 1),(
    36,
    'MANTENIMIENTO',
    'MANT',
    'MANTENIMIENTO',
    'Sin Asignar',
    1
  ),(37, 'ROPERIA', 'ROP', 'ROPERIA', 'Sin Asignar', 1),(
    38,
    'BANCO SANGRE',
    'BANC',
    'BANCO SANGRE',
    'Sin Asignar',
    1
  ),(
    39,
    'INVENTARIOS',
    'INV',
    'INVENTARIOS',
    'Sin Asignar',
    1
  ),(40, 'Ivonne', 'FDDF', 'fdgdfgdfg', 'dfsdfs', 0);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: device_custom_values
# ------------------------------------------------------------

INSERT INTO
  `device_custom_values` (`id`, `device_id`, `custom_field_id`, `value`)
VALUES
  (515, 174, 1, '10.1.40.53'),(516, 174, 2, 'WD Green 2.5 480GB SSD'),(517, 174, 4, '8 GB'),(518, 174, 5, 'Intel Core i5-10500T 2.30GHz'),(519, 175, 1, '10.1.40.198'),(520, 175, 2, 'SSD WDC WDS480G2G0A 447GB'),(521, 175, 4, '4.0GB DDR3'),(522, 175, 5, 'Intel Core i5-6500T 2.50GHz'),(523, 176, 1, '10.1.40.12'),(524, 176, 2, 'SSD WD GREEN 480-447GB'),(525, 176, 4, '4 GB DDR3'),(526, 176, 5, 'Intel Core i5-6500T 2.50GHz'),(527, 177, 1, '10.1.40.52'),(528, 177, 2, 'SSD WD GREEN 447GB'),(529, 177, 4, '12 GB'),(530, 177, 5, 'INTEL CORE I3-6100T CPU 3.20GHz'),(531, 178, 1, '10.1.40.96'),(532, 178, 2, 'WD Green 2.5 480GB SSD'),(533, 178, 4, '16 GB DDR3'),(534, 178, 5, 'Intel(R) Core(TM) i5-6500 2.50GHz'),(535, 179, 1, '10.1.40.14'),(536, 179, 2, 'WD Green 2.5 480GB SSD'),(537, 179, 4, '12 GB DDR3'),(538, 179, 5, 'Intel(R) Core(TM) i5-6500 2.50GHz'),(539, 180, 1, '10.1.1.154'),(540, 180, 2, 'SSD NVME256GGB'),(541, 180, 4, '1X16GB'),(542, 180, 5, 'INTEL CORE I5-12500T'),(543, 181, 1, '10.1.1.56'),(544, 181, 2, 'SSD 256GB'),(545, 181, 4, '1X16GB'),(546, 181, 5, 'INTEL CORE I5-12500T'),(547, 182, 1, '10.1.30.75'),(548, 182, 2, 'SSD WDC WDS480G2G0A-00JH30 447GB'),(549, 182, 4, '8 GB'),(550, 182, 5, 'INTEL CORE I5-10500T CPU 2.30GHz'),(551, 183, 1, '10.1.50.207'),(552, 183, 2, 'SSD KINGSTON 480GB'),(553, 183, 4, '8 GB DDR3'),(554, 183, 5, 'INTEL CORE i5-6500T 2.50GHz'),(555, 184, 1, '10.1.50.102'),(556, 184, 2, 'SSD NVMe PM991a 256GB'),(557, 184, 4, '12GB'),(558, 184, 5, '12TH GEN INTEL CORE I5-12500T2GHz'),(559, 185, 1, '10.1.50.240'),(560, 185, 2, 'SSD WDC 447GB'),(561, 185, 4, '12 GB'),(562, 185, 5, 'INTEL CORE I5-6500T CPU 2.50GHz'),(563, 186, 1, '10.1.30.189'),(564, 186, 2, 'SSD WDC 447GB'),(565, 186, 4, '8 GB'),(566, 186, 5, 'INTEL CORE I3-8100T 3.10GHz'),(567, 187, 1, '10.1.10.34'),(568, 187, 2, 'SSD NVMe Micron 2450 256GB'),(569, 187, 4, '16 GB'),(570, 187, 5, '12th Gen Intel Core i5-12500'),(571, 188, 1, '10.1.30.43'),(572, 188, 2, 'SSD NVMe PM991a Samsuung 256GB'),(573, 188, 4, '16 GB'),(574, 188, 5, '12 Gen Intel Core i5-12500T 2GHz'),(575, 189, 1, '10.1.50.17'),(576, 189, 2, 'SSD WD GREEN 480GB'),(577, 189, 4, '1X4GB 1600MHz DDR3'),(578, 189, 5, 'INTEL CORE I5-6500T'),(579, 190, 1, '10.1.30.13'),(580, 190, 2, 'SSD NVMe BC711 SK hynix 256GB'),(581, 190, 4, '8 GB'),(582, 190, 5, '12 Gen Intel Core i5-12500T 2GHz'),(583, 191, 1, '10.1.40.37'),(584, 191, 2, 'WD Green 2.5 480GB SSD'),(585, 191, 4, '4.0 GB DDR3'),(586, 191, 5, 'i5-6500T 2.5GHz'),(587, 192, 1, '10.1.40.38'),(588, 192, 2, 'HDD 480 GB'),(589, 192, 4, '4.0 GB DDR3'),(590, 192, 5, 'i5-6500T 2.5GHz'),(595, 195, 1, '10.1.10.202'),(596, 195, 2, 'SSD WDS 480GB'),(597, 195, 4, '4GB DDR3'),(598, 195, 5, 'INTEL CORE I5-6500T 2.5GHz'),(599, 197, 2, '512 GB  SSD'),(600, 197, 4, '8GB'),(601, 197, 5, 'INTEL CORE I5'),(602, 198, 1, '10.1.30.30'),(603, 198, 2, 'SSD WD GREEN 2.4 447GB'),(604, 198, 4, '8 GB'),(605, 198, 5, 'INTEL CORE I5-10500t 2.30GHz'),(606, 200, 1, '10.1.30.189'),(607, 200, 2, 'SSD WDC 447GB'),(608, 200, 4, '8 GB'),(609, 200, 5, 'INTEL CORE I3-8100T 3.10GHz'),(610, 201, 1, '10.1.40.22'),(611, 201, 2, 'SSD KINGSTONE 480GB'),(612, 201, 4, '1X8GB 2666MHz'),(613, 201, 5, 'INTEL CORE I5-10500T'),(614, 202, 1, '10.1.50.216'),(615, 202, 2, 'SSD WDG 480GB'),(616, 202, 4, '2x4 GB DDR3'),(617, 202, 5, 'INTEL CORE I3-7100'),(618, 203, 1, '10.1.60.86');
INSERT INTO
  `device_custom_values` (`id`, `device_id`, `custom_field_id`, `value`)
VALUES
  (619, 203, 2, 'WD Green 2.5 480GB SSD'),(620, 203, 4, '8.0 GB'),(621, 203, 5, 'i3-81T 3.10 GHz'),(622, 204, 1, '10.1.60.14'),(623, 204, 2, 'HDD466GB'),(624, 204, 4, '12GB DDR3'),(625, 204, 5, 'INTEL CORE I5-6500T'),(626, 206, 1, '10.1.60.17'),(627, 206, 2, 'SSD NVME 256GB'),(628, 206, 4, '1X8 GB 3200MHz'),(629, 206, 5, 'INTEL CORE I5-12500T'),(630, 209, 1, '10.1.50.200'),(631, 209, 2, 'SSS 480GB'),(632, 209, 4, '1X4GB'),(633, 209, 5, 'I3 8100 3.2 GHX'),(634, 213, 1, '10.1.4.30'),(635, 213, 2, 'SSD WD 480GB'),(636, 213, 4, '1X4GB  DDR3'),(637, 213, 5, 'INTEL CORE I5-6500T'),(638, 214, 1, '10.1.4.38'),(639, 214, 2, 'SSD(NVME) MICRON 256GB'),(640, 214, 4, '1X16GB'),(641, 214, 5, 'INTEL CORE I5-12500T'),(642, 215, 1, '10.1.4.12'),(643, 215, 2, 'SSD(NVME)SAMSUNG 256GB'),(644, 215, 4, '1X16 GB'),(645, 215, 5, 'INTEL CORE I5-13500T'),(646, 216, 1, '10.1.50.52'),(647, 216, 2, 'SSD WDG 480GB'),(648, 216, 4, '4GB DDR3'),(649, 216, 5, 'INTEL CORE I5-6500T'),(650, 217, 2, 'HDD'),(651, 217, 4, '1X8GB DDR3'),(652, 217, 5, 'INTEL CORE I5-6500T'),(653, 218, 2, 'SSD WDC 480GB'),(654, 218, 4, '2X4GB 2133MHz'),(655, 218, 5, 'INTEL CORE I3-7100'),(656, 220, 1, '10.1.50.85'),(657, 220, 2, 'SSD WDC 480GB'),(658, 220, 4, '1X8GB'),(659, 220, 5, 'INTEL CORE I5-10500T'),(660, 221, 1, '10.1.50.73'),(661, 221, 2, 'SSD ADATA630GB'),(662, 221, 4, '1 X16 GB'),(663, 221, 5, 'INTEL CORE I5-10500T'),(664, 222, 1, '10.1.50.214'),(665, 222, 2, 'SSD ADATA 630'),(666, 222, 4, '12GB DDR3'),(667, 222, 5, 'INTEL CORE I5-6500T'),(668, 223, 1, '10.1.50.25'),(669, 223, 2, 'HDD 500GB'),(670, 223, 4, '1X4 GB DDR3'),(671, 223, 5, 'INTEL CORE I5-6500T'),(672, 224, 1, '10.1.8.221'),(673, 224, 2, 'HDD 500GB'),(674, 224, 4, '12 GB'),(675, 224, 5, 'INTEL CORE I5-6500T'),(676, 225, 1, '10.1.50.47'),(677, 225, 2, 'SSD WD GREEN 2.5 447GB'),(678, 225, 4, '4.0GB DDR3'),(679, 225, 5, 'INTEL CORE i5-6500T 2.5GHz'),(680, 227, 1, '10.1.4.40'),(681, 227, 2, 'SSD GREEN 2.5 480GB'),(682, 227, 4, '8 GB'),(683, 227, 5, 'INTEL CORE I5-10500T 2.3GHz'),(684, 229, 1, '10.1.4.150'),(685, 229, 2, 'SSD WDC 224GB'),(686, 229, 4, '4GB DDR3'),(687, 229, 5, 'INTEL CORE I5-6500T 2.50GHz'),(688, 230, 1, '10.1.10.21'),(689, 230, 2, 'SSD NVMe MICRON 2450 256GB'),(690, 230, 4, '16GB'),(691, 230, 5, '12th GEN INTEL CORE I5-12500T 2GHz'),(692, 231, 1, '10.1.10.1'),(693, 231, 2, 'SSD WDC 447GB'),(694, 231, 4, '4GB DDR3'),(695, 231, 5, 'INTEL CORE I5-6500T 2.50 GHz'),(696, 232, 1, '10.1.50.146'),(697, 232, 2, 'SSD WDC 447GB'),(698, 232, 4, '4GB DDR3'),(699, 232, 5, 'INTEL CORE I5-6500T 2.50 GHz'),(700, 236, 1, '10.1.10.20'),(701, 236, 2, 'WDS480G2G0A-00JH30'),(702, 236, 4, '4.0 GB'),(703, 236, 5, 'i3-8100T 3.10GHz'),(704, 237, 1, '10.1.10.150'),(705, 237, 2, 'WD Green 2.5 480GB SSD'),(706, 237, 4, '8.0 GB'),(707, 237, 5, 'i5-10500T CPU 2.30 GHz'),(708, 238, 1, '10.1.10.60'),(709, 238, 2, 'WDC WDS480G3G0A-00JH30'),(710, 238, 4, '4.0 GB DDR3'),(711, 238, 5, 'i7-6700 CPU 3.40GHz'),(712, 239, 1, '10.1.10.104'),(713, 239, 2, 'WDS480G2G0A-00JH30'),(714, 239, 4, '4.0 GB DDR3'),(715, 239, 5, 'i5-6500T 2.50GHz'),(716, 240, 1, '10.1.10.195'),(717, 240, 2, 'ADATA SU630'),(718, 240, 4, '8.0 GB DDR3');
INSERT INTO
  `device_custom_values` (`id`, `device_id`, `custom_field_id`, `value`)
VALUES
  (719, 240, 5, 'i5-6500T 2.50GHz'),(720, 241, 1, '10.1.10.115'),(721, 241, 2, 'WDC WDS480G2G0A-00JH30'),(722, 241, 4, '4.0 GB'),(723, 241, 5, 'i3-8100T 3.10GHz'),(724, 242, 1, '10.1.10.94'),(725, 242, 2, 'ST1000LM049-2GH172'),(726, 242, 4, '8.0 GB'),(727, 242, 5, 'i5-10500T CPU 2.30 GHz'),(728, 243, 1, '10.1.10.179'),(729, 243, 2, 'TOSHIBA MQ01ACF050'),(730, 243, 4, '16.0 GB DDR3'),(731, 243, 5, 'i5-6500T CPU 2.50GHz'),(732, 245, 1, '10.1.10.122'),(733, 245, 2, 'TOSHIBA MQ01ACF050'),(734, 245, 4, '8.0GB DDR3'),(735, 245, 5, 'i5-6500T 2.50 GHz'),(736, 246, 1, '10.1.10.146'),(737, 246, 2, 'WD Green 2.5 480GB SSD'),(738, 246, 4, '4.0 GB DDR3'),(739, 246, 5, 'i5-6500T 2.50GHz'),(740, 247, 2, 'HDD WDC 466GB'),(741, 247, 4, '8 GB'),(742, 247, 5, 'INTEL CORE I5-4460 3.20GHz'),(743, 248, 2, 'SSD WDC 447GB'),(744, 248, 4, '4 GB'),(745, 248, 5, 'Intel Core i3-6100 3.70GHz'),(746, 249, 2, 'SSD WD GREEN 447GB'),(747, 249, 4, '4 GB'),(748, 249, 5, 'INTEL CORE I3-6100 3.70GHz'),(749, 250, 2, 'SSD WD GREEN 447GB'),(750, 250, 4, '8GB'),(751, 250, 5, 'INTEL CORE I5-7500 3.40GHz'),(752, 251, 1, '10.1.40.212'),(753, 251, 2, 'WD Green 2.5 480GB SSD'),(754, 251, 4, '2X8 2666MHz'),(755, 251, 5, 'INTEL CORE I5-10500T'),(756, 252, 1, '10.1.40.99'),(757, 252, 2, 'DISCO HDD TOSHIBA 932GB'),(758, 252, 4, '2X4GB 2133MHz'),(759, 252, 5, 'INTEL CORE I3-6100'),(760, 253, 1, '10.1.20.13'),(761, 253, 2, 'DISCO SSD WDC 480GB'),(762, 253, 4, '1X8GB 2666MHz'),(763, 253, 5, 'INTEL CORE I5-10500T'),(764, 254, 1, '10.1.40.75'),(765, 254, 2, 'SSS WDS 480GB'),(766, 254, 4, '1X4GB DDR3'),(767, 254, 5, 'INTEL CORE I3-6100T CPU 3.20GHz'),(768, 255, 1, '10.1.50.5'),(769, 255, 2, 'SSD WDG 480GB'),(770, 255, 4, '1X4 GGB'),(771, 255, 5, 'INTEL CORE I3-7100T'),(772, 256, 7, 'SSD WD GREEN 480GB'),(773, 256, 8, 'Intel Core I7-8550U'),(774, 256, 9, '8gB'),(775, 258, 7, 'SSD 239G'),(776, 258, 8, 'INTEL CORE I5-10210'),(777, 258, 9, '2X8 GB'),(778, 259, 7, 'SSD SAMSUNG 477GB'),(779, 259, 8, 'INTEL CORE 12th Gen i7 1.70GHz'),(780, 259, 9, '16 GB DDR3'),(781, 260, 7, 'SSD ADATA SU 630 447GB'),(782, 260, 8, 'INTEL CELERON N4000 1.10GHz'),(783, 260, 9, '1x4GB 2400MHz'),(784, 262, 8, 'INTEL CORE I3-6006U'),(785, 262, 9, '4GB'),(786, 266, 7, 'BC511 NVMe SK hynix 512GB'),(
    787,
    266,
    8,
    'AMD Ryzen 5 4600H with Radeon Graphics'
  ),(788, 266, 9, '8.0 GB'),(789, 273, 7, 'SSD 128GB'),(790, 273, 8, 'INTEL CORE I7-6500U'),(791, 273, 9, '1X8gb'),(792, 274, 7, 'DISCO SSD (NVMe) 477 GB'),(793, 274, 8, 'INTEL CORE I7  150U'),(794, 274, 9, '2X8GB 3200 MT/S'),(795, 536, 14, '20-23-51-2E-C2-54'),(796, 536, 15, '12B6-C129-D0E2-7B52-1000'),(797, 536, 16, 'IDF 1 Puerto 3'),(798, 537, 14, '5C-E9-31-1D-07-8C'),(799, 537, 15, ''),(800, 537, 16, 'IDF 1 Puerto 2'),(801, 538, 14, 'B0-19-21-7E-24-78'),(802, 538, 15, '1BB5-662C-DE80-BB15-1000'),(803, 538, 16, 'IDF 1 P1'),(804, 539, 14, 'B0-19-21-7E-28-76'),(805, 539, 15, '1BB5-662C-DE40-536D-D000'),(806, 539, 16, 'IDF2 Puerto 3'),(807, 540, 14, 'B0-19-21-7E-28-0A'),(808, 540, 15, '1BB5-66SC-DE47-92B9-5000'),(809, 540, 16, 'IDF2 Puerto 2'),(810, 541, 14, '30-68-93-E2-A3-94'),(811, 541, 15, '13B2-7D05-16FE-7461-4000'),(812, 541, 16, 'IDF2 Puerto 1'),(813, 542, 14, '20-23-51-2E-C5-AC'),(814, 542, 15, '12B6-C129-D09D-FB65-2000'),(815, 542, 16, 'IDF 3 Puerto 3'),(816, 543, 14, 'B0-19-21-7E-28-1A'),(817, 543, 15, '18B5-662C-DE46-9F31-1000'),(818, 543, 16, 'IDF 3 Puerto 2');
INSERT INTO
  `device_custom_values` (`id`, `device_id`, `custom_field_id`, `value`)
VALUES
  (819, 544, 14, '5C-E9-31-1D-02-2E'),(820, 544, 15, ''),(821, 544, 16, 'IDF 3 Puerto 1'),(822, 545, 14, '5C-E9-31-1D-02-26'),(823, 545, 15, ''),(824, 545, 16, 'SITE Puerto 12'),(825, 546, 14, 'D8-44-89-76-FB-5E'),(826, 546, 15, '1D30-BCAC-5372-D34F-7000'),(827, 546, 16, 'SITE Puerto 11'),(828, 547, 14, 'F0-A7-31-1B-60-C6'),(829, 547, 15, ''),(830, 547, 16, 'SITE Puerto 10'),(831, 548, 14, '30-68-93-E2-A5-60'),(832, 548, 15, '13B2-7D05-1691-3903-C000'),(833, 548, 16, 'SITE Puerto 9'),(834, 549, 14, '20-23-51-2E-BF-F0'),(835, 549, 15, '12B6-C129-D738-3555-0000'),(836, 549, 16, 'SITE Puerto 8'),(837, 550, 14, '48-22-54-40-45-BA'),(838, 550, 15, ''),(839, 550, 16, 'SITE Puerto 7'),(840, 551, 14, 'D8-44-89-77-00-8E'),(841, 551, 15, '1D30-BCAC-4CCF-D521-A000'),(842, 551, 16, 'SITE Puerto 6'),(843, 552, 14, 'A8-42-A1-F1-2C-10'),(844, 552, 15, '1A30-DE24-2E06-36B2-4000'),(845, 552, 16, 'SITE Puerto 4'),(846, 553, 14, '20-23-51-2E-C0-DC'),(847, 553, 15, '12B6-C129-D0CA-F674-C000'),(848, 553, 16, 'SITE Puerto 3'),(849, 554, 14, '20-23-51-2E-C1-EE'),(850, 554, 15, '12B6-C129-D0D9-DC94-7000'),(851, 554, 16, 'SITE Puerto 2'),(852, 555, 14, '20-23-51-2E-C7-7E'),(853, 555, 15, '12B6-C129-B0B0-DFF4-7000'),(854, 555, 16, 'SITE Puerto 2'),(855, 556, 14, '20-23-51-2E-C4-1E'),(856, 556, 15, '12B6-C129-D086-D27E-C000'),(857, 556, 16, 'SITE Puerto 1');

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: device_groups
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: devices
# ------------------------------------------------------------

INSERT INTO
  `devices` (
    `id`,
    `brand`,
    `model`,
    `serial_number`,
    `category_id`,
    `group_id`,
    `status`,
    `details`,
    `func`,
    `is_new`
  )
VALUES
  (
    1,
    'GHIA',
    'GPOS115',
    'OGPOS115180658300143',
    3,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    2,
    'DELL',
    'INSPIRON 5400 AIO SERIES',
    'CN-0X74T0-PE200-0AK-0054-A00',
    3,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    172,
    'DELL',
    'OPTIPLEX 3060',
    '9FBXZS2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    173,
    'DELL',
    'OPTIPLEX3000',
    '25KGXP3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    174,
    'DELL',
    'OPTIPLEX 3080 MICRO',
    '8RVCF93',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    175,
    'DELL',
    'OPTIPLEX 3040',
    '8D40DH2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    176,
    'DELL',
    'OPTIPLEX 3040',
    '33ZMDH2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    177,
    'DELL',
    'OPTIPLEX3050',
    'G2V3JK2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    178,
    'DELL',
    'OPTIPLEX3040M',
    '8SHLQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    179,
    'DELL',
    'OPTIPLEX3040M',
    'B1RLCH2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    180,
    'DELL',
    'OPTIPLEX3000',
    '8LR0GT3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    181,
    'DELL',
    'OPTIPLEX 3000',
    '631K1V3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    182,
    'DELL',
    'OPTIPLEX3080',
    'FQHKF73',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    183,
    'DELL',
    'OPTIPLEX 3000 MICRO',
    '8T3LQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    184,
    'DELL',
    'OPTIPLEX 3040',
    'HLFJ1V3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    185,
    'DELL',
    'OPTIPLEX MICRO 3040M',
    '8T3MQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    186,
    'DELL',
    'OPTIPLEX MICRO',
    'HQPFZT2/38620156934',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    187,
    'DELL',
    'OPTIPLEX 3000 MICRO',
    '4PR0GT3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    188,
    'DELL',
    'OPTIPLEX 3000 Micro',
    '1RJJ1V3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    189,
    'DELL',
    'OPTIPLEX 3040',
    '8SWJQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    190,
    'DELL',
    'OPTIPLEX3000',
    'BPQZZQ3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    191,
    'DELL',
    'OPTIPLEX 3040',
    '8SKLQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    192,
    'DELL',
    'OPTIPLEX 3040',
    '6QXZ482',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    194,
    'DELL',
    'OPTIPLEX 3050',
    '8T9NQP2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    195,
    'DELL',
    'OPTIPLEX3040',
    'CL0NQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    196,
    'DELL',
    'OPTIPLEX 3080',
    'H37TB93',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    197,
    'DELL',
    'OPTIPLEX Micro 7010',
    '38R7Z24',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    198,
    'DELL',
    'OPTIPLEX 3080',
    'FKC1LB3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    199,
    'DELL',
    'OPTIPLEX 3080',
    'F1NHF73',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    200,
    'DELL',
    'OPTIPLEX 3040',
    '344GDH2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    201,
    'DELL',
    'OPTIPLEX3080',
    'C27YB93',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    202,
    'DELL',
    'OPTIPLEX 3050',
    'H4199N2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    203,
    'DELL',
    'OPTIPLEX 3060',
    '34Q0DV2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    204,
    'DELL',
    'OPTIPLEX 3040',
    '8SQGQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    205,
    'DELL',
    'OPTIPLEX3000',
    'CRR0QR3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    206,
    'DELL',
    'OPTIPLEX3000',
    '7LQ0QR3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    207,
    'DELL',
    'OPTIPLEX3040',
    '8SMKQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    208,
    'DELL',
    'OPTIPLEX 7040',
    'HS0JFB2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    209,
    'DELL',
    'OPTIPLEX3060',
    'CQDQ8X2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    210,
    'DELL',
    'OPTIPLEX3040',
    '8T4HQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    211,
    'DELL',
    'OPTIPLEX3080',
    'C0DCCD3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    212,
    'DELL',
    'OPTIPLEX3040',
    '8SPJQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    213,
    'DELL',
    'OPTIPLEX3040',
    '6QWY482',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    214,
    'DELL',
    'OPTIPLEX3000',
    '1Y3H0R3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    215,
    'DELL',
    'OPTIPLEX3000',
    '760Z7Y3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    216,
    'DELL',
    'OPTIPLEX3040',
    '8SZLQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    217,
    'DELL',
    'OPTIPLEX3040',
    '8SVFQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    218,
    'DELL',
    'OPTIPLEX3050',
    'HR65DP2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    220,
    'DELL',
    'OPTIPLEX3080',
    '1NHKF73',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    221,
    'DELL',
    'OPTIPLEX 3080',
    'G57TB93',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    222,
    'DELL',
    'OPTIPLEX 3040',
    'B1XHCH2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    223,
    'DELL',
    'OPTIPLEX3040',
    '8T1GQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    224,
    'DELL',
    'OPTIPLEX3040',
    '8T1MQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    225,
    'DELL',
    'OPTIPLEX3040',
    '8SMLQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    227,
    'DELL',
    'OPTIPLEX3080 MICRO',
    '957TB93',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    228,
    'DELL',
    'OPTIPLEX 3000',
    'P9XD3GT3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    229,
    'DELL',
    'OPTIPLEX3040',
    'B1PPCH2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    230,
    'DELL',
    'OPTIPLEX3040',
    '8SVHQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    231,
    'DELL',
    'OPTIPLEX 3000',
    'DXP0GT3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    232,
    'DELL',
    'OPTIPLEX3040',
    '340KDH2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    233,
    'DELL',
    'OPTIPLEX3060',
    'CPYP8X2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    234,
    'DELL',
    'OPTIPLEX 3000',
    '1Z8V7Y3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    235,
    'DELL',
    'OPTIPLEX3000',
    '66KGXP3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    236,
    'DELL',
    'OPTIPLEX3060',
    'HLVFZT2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    237,
    'DELL',
    'OPTIPLEX3080',
    '2W4TB93',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    238,
    'DELL',
    'OPTIPLEX7040',
    'G6M7DH2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    239,
    'DELL',
    'OPTIPLEX3040',
    '8SLLQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    240,
    'DELL',
    'OPTIPLEX3040',
    '8T2GQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    241,
    'DELL',
    'OPTIPLEX3060',
    '9BBXZS2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    242,
    'DELL',
    'OPTIPLEX3080',
    'CQ4TB93',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    243,
    'DELL',
    'OPTIPLEX3040',
    '8T4GQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    245,
    'DELL',
    'OPTIPLEX3040',
    '33ZNDH2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    246,
    'DELL',
    'OPTIPLEX3040',
    '8T1HQD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    247,
    'LENOVO',
    'THINK CENTRE M73',
    'MJ02YW0M',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    248,
    'HP',
    'HP 280 G2 SFF BUSINESS PC',
    '4CE7233H26',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    249,
    'HP',
    'HP280G2FF',
    '4CE7233GWT',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    250,
    'DELL',
    'OPTIPLEX3050SFF',
    '1T1M7M2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    251,
    'DELL',
    'OPTIPLEX 3080',
    'JLQ5DD3',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    252,
    'HP',
    'HP 280 G2 SFF BUSINESS PC',
    '4CE7233H5P',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    253,
    'DELL',
    'OPTIPLEX3080',
    'GV4TB93',
    1,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    254,
    'DELL',
    'OPTIPLEX3040',
    'G79MSD2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    255,
    'DELL',
    'OPTIPLEX3050',
    '4VM0MN2',
    1,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    256,
    'LENOVO',
    '81B0',
    'MP1GQEMH',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    257,
    'HP',
    '15-ae106la',
    'CND5525VK0',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    258,
    'DELL',
    'Latitude 3510',
    'B4C8863',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    259,
    'HP',
    'HSN-Q32C-4',
    'SCD4297LX0',
    2,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    260,
    'LENOVO',
    'IDEAPAD 330GM',
    'PF176YXX',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    261,
    'HP',
    '15-cw1005la',
    '5CD041JPYZ',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    262,
    'HP',
    '14-bs012la',
    '5CD73671WG',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    263,
    'ASUS',
    'X409F',
    'L7N0CX02P394276',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    264,
    'HP',
    '7265NGW',
    'CND5525VBW',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    265,
    'ASUS',
    'UX3402Z Notebook PC',
    'N5N0LPOOL81119F',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    266,
    'DELL',
    'P89F',
    '75N8X93',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    267,
    'HP',
    '15-bs020la',
    'CND7338KQG',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    268,
    'HP',
    'HP ProBook 440 G8',
    '5CD206HDQ5',
    2,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    269,
    'HP',
    'HP ProBook 440 G8',
    '5CD2250Q0Z',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    270,
    'HP',
    'HP ProBook 440 G8',
    '5CD206HDRH',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    271,
    'HP',
    '15-ae106la',
    'CND5460SB2',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    273,
    'HP',
    '15-as004la',
    '5CG631315Z',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    274,
    'HP',
    'AX211NGW',
    '8CG4231X1Y',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  );
INSERT INTO
  `devices` (
    `id`,
    `brand`,
    `model`,
    `serial_number`,
    `category_id`,
    `group_id`,
    `status`,
    `details`,
    `func`,
    `is_new`
  )
VALUES
  (
    275,
    'ASUS',
    'X409F',
    'L7N0CX02P429278',
    2,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    276,
    'LOGITECH',
    'K120',
    '1628SC5122X8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    277,
    'DELL',
    'KB2016tf',
    'CN-01KMDJ-LO300-25R-K01L-A01',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    278,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-8AG-081M-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    279,
    'LOGITECH',
    'K120',
    '2144SC33M7H8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    280,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-03H-0U9O-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    281,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-11U-05CY-A04',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    282,
    'LOGITECH',
    'K220',
    '2116SC10QM58',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    283,
    'LOGITECH',
    'K220',
    '2116SC10QMN8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    284,
    'DELL',
    'KB216t',
    'CN-0006HY-PRC00-27B-B3GU-A01',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    285,
    'DELL',
    'KB216t',
    'CN-0081N8-LO300-2AR-0BII-A01',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    286,
    'LOGITECH',
    'K120',
    '2207SC31XXY8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    287,
    'DELL',
    'KB216/0F2JV2',
    'CN-0F2N2-LO300-119-0O9R-A04',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    288,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-A01',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    289,
    'LOGITECH',
    'M185',
    '2053LZMJC3K8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    290,
    'DELL',
    'K120',
    '2337MR2A1B48',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    291,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-69K-AMPB-A00',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    292,
    'DELL',
    'KB216t3',
    'CN-0081N8-LO300-26G-1BWU-A01',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    293,
    'DELL',
    'KB216P',
    'CN-08NYJV-PRC00-844-0112-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    294,
    'DELL',
    'KB216t1',
    'CN-019M93-LO300-1CD-0CE1-A00',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    295,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-67L-1FXI-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    296,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-67L-1DZL-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    297,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-67L-1JUS-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    298,
    'LOGITECH',
    'K220',
    '1848SC10AEF8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    299,
    'LOGITECH',
    'K120',
    '2337MR2A0098',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    300,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-0BU-00UR-A04',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    301,
    'LOGITECH',
    'K120',
    '2401MR121EA8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    302,
    'LOGITECH',
    'K120',
    '2337MR2A00B8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    303,
    'LOGITECH',
    'M100',
    '2330HS04FYY8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    304,
    'DELL',
    'KB216t',
    'CN-0FJV2-71616-67L-1DUA-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    305,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-11U-04J4-A04',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    306,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-831-027Q-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    307,
    'LOGITECH',
    'K120',
    '2144SC33M7L8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    308,
    'LOGITECH',
    'K120',
    '2138SC305EQ8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    309,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-12N-0RTF-A04',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    310,
    'DELL',
    'KB216t1',
    'CN-019M93-LO300-1CD-0I4P-A00',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    311,
    'LOGITECH',
    'K120',
    '2337MR2A00C8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    312,
    'LENOVO',
    'SK-8823',
    '8SSD50L21264AVLC9CC0KKA',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    313,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-8AO-0G9E-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    314,
    'DELL',
    'KB216t',
    'CN-F2JV2-L0300-0CT-0L7I-A04',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    315,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-74F-0DXQ-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    316,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-88I-0BTY-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    317,
    'LOGITECH',
    'K120',
    '2337MR2A1BB8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    318,
    'DELL',
    'KB216p',
    'CN-0006HY-PRC00-24T-02CB-A00',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    319,
    'DELL',
    'KB216t3',
    'CN-019M93-LO300-31B-G3GB-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    320,
    'DELL',
    'nan',
    'CN-0F2V2-71616-67L-1JUM-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    321,
    'DELL',
    'E1916H',
    'CN-0F2JV2-71616-67L-1JUU-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    322,
    'LOGITECH',
    'K120',
    '2138SC3055G8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    323,
    'DELL',
    'nan',
    'CN-0F2JV2-71616-67L-1JUP-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    324,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-67L-1JUL-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    325,
    'LOGITECH',
    'K120',
    '2337MR2A00A8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    326,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-0BU-00SZ-A04',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    327,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-67L-1JUT-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    328,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-03J-170D-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    329,
    'DELL',
    'KB216d',
    'CN-01GN56-M6D00-0C1-04BB-A02',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    330,
    'DELL',
    'WK118',
    'CN-0J5K9F-LO300-0CS-K227-A01',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    332,
    'LOGITECH',
    'K120',
    '2138SC3055H8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    333,
    'DELL',
    'KB216p',
    'CN-0006HY-PRC00-26N-A5Q6-A01',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    334,
    'LOGITECH',
    'K120',
    '2337MR2A1BA8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    335,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-699-0392-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    336,
    'DELL',
    'KB216p',
    'CN-0006HY-PRC00-27B-B3GQ-A01',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    337,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-699-05LY-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    338,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-8AO-0G9D-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    339,
    'DELL',
    'KB216t3',
    'CN-019M93-LO300-31B-G1PX-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    340,
    'LOGITECH',
    'M-110s',
    '810-006279',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    341,
    'DELL',
    'KB216t1',
    'CN-01KMDJ-LO300-275-K13C-A01',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    342,
    'Perfect Choice',
    'PC-0044819',
    'L413044819',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    343,
    'LOGITECH',
    'M-U0026',
    '810-002182',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    345,
    'LOGITECH',
    'M-U0026',
    '810-002182/HS335HE',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    347,
    'LOGITECH',
    'M100',
    '2330HS04FYS8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    348,
    'LOGITECH',
    'M150',
    'CCAI13LP0700T8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    350,
    'LOGITECH',
    'M100',
    '2330HS04FYT8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    351,
    'DELL',
    'MS116P',
    'CN-009NK2-73826-6CO-14OX',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    352,
    'LOGITECH',
    'M100',
    '2313HS02RX78',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    353,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-6AC-15R8-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    355,
    'Dell',
    'KB216t',
    'CN-0F2JV2-LO300-833-1521-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    356,
    'HP',
    'KU-0316',
    'BDALC0N5Y7I057',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    357,
    'LOGITECH',
    'K120',
    '2144SC33M7E8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    358,
    'LOGITECH',
    'KB216t',
    'CN-2JV2-71616-57L-1JRC-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    359,
    'LOGITECH',
    'K120',
    '2144SC33M7M8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    360,
    'LOGITECH',
    'K120',
    '2314MR05C408',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    361,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-67L-1HUQ-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    362,
    'DELL',
    'KB216t',
    'CN-0F2JV2-LO300-04P-0BG7-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    363,
    'DELL',
    'KB216t',
    'CN-0F2JV2-71616-676-1CBH-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    364,
    'DELL',
    'KB216',
    'CN-0F2JV2-LO300-7CN-0A3C-A03',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    365,
    'LOGITECH',
    'M185',
    '2241LZX3TWA8',
    4,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    366,
    'DELL',
    'MS116P',
    'CN-009NK2-73826-66R-019U',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    367,
    'LOGITECH',
    'M185',
    '2217LZX5G0K8',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    368,
    'DELL',
    'MS116t1',
    'CN-01KMDJ-LO300-25R-M01L',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    369,
    'LOGITECH',
    'M100',
    '2330HS04FV18',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    370,
    'LOGITECH',
    'M-U0026',
    '810-002182/HS142HB',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    371,
    'LOGITECH',
    'M100',
    '2330HS04FYX8',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    372,
    'LOGITECH',
    'M185',
    '2116LZX5JU98',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    373,
    'LOGITECH',
    'M110s',
    '2013DJ6343',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    374,
    'LOGITECH',
    'M110S',
    '2351HS043UZ8',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    375,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-29K-03JA',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    376,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-29F-0QSY',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    378,
    'DELL',
    'M-U0026',
    'HS313HB/810-002182',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    379,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-25D-0W0M',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    380,
    'DELL',
    'P2018H',
    'CN-0RYK5R-TV200-13B-0KKU-A13',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  );
INSERT INTO
  `devices` (
    `id`,
    `brand`,
    `model`,
    `serial_number`,
    `category_id`,
    `group_id`,
    `status`,
    `details`,
    `func`,
    `is_new`
  )
VALUES
  (
    382,
    'DELL',
    'E2020H',
    'CN-08RWX5-QDC00-0AE-1KDI-A03',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    383,
    'DELL',
    'MS116t',
    'CN-065K5F-LO300-25D-0W0K',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    384,
    'DELL',
    'MS116P',
    'CN-009NK2-73826-66R-01AI',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    385,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-23P-0B5F',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    386,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-29K-03HD',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    387,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-04G-095S',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    388,
    'LOGITECH',
    'M-U0026',
    '810-002182HS309HB',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    389,
    'DELL',
    'M-U0026',
    '810-002182HS335HE',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    390,
    'LOGITECH',
    'M110S',
    '2351HS044CK8',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    393,
    'LOGITECH',
    'MS116T1',
    'CN-065K5F-LO300-353-0UBS',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    394,
    'LOGITECH',
    'M185',
    '2228LZXH2E48',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    395,
    'DELL',
    'MS116t1',
    'CN-081FT1-LO300-04D-01A0',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    396,
    'LENOVO',
    'MOIUUO',
    '00BRVHC',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    397,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-0C2-082V',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    398,
    'LOGITECH',
    'M100',
    '2228HS04NH48',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    399,
    'LOGITECH',
    'U0026',
    'HS202HB',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    400,
    'DELL',
    'MS116T1',
    'CN-065K5F-LO300-24N-OBNH',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    401,
    'DELL',
    'MS116t',
    'CN-0DV0RH-71616-75G-08G7',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    402,
    'LOGITECH',
    'M185',
    '2115LZX4LGF8',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    403,
    'DELL',
    'MS116t1',
    'CN-0PRDV9-LO300-8BT-04ZO',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    404,
    'LOGITECH',
    'M-U0026',
    '810-002182 / HS313HB',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    405,
    'LOGITECH',
    'M100',
    '2330HS04FYW8',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    406,
    'LOGITECH',
    'M100',
    '2330HS04FV28',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    407,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-25J-0BFF',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    409,
    'DELL',
    'MS116p',
    'CN-009NK2-73826-66R-0197',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    410,
    'LOGITECH',
    'M-U0026',
    '810-002182 / HS135HB',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    411,
    'KENSINGTON',
    'M01496/902-4129-00',
    'Q2130D000741',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    412,
    'DELL',
    'MS116t1',
    'CN-081FT1-LO300-04D-01B1',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    413,
    'DELL',
    'MS116t1',
    'CN-081FT1-LO300-04D-019Z',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    414,
    'HP',
    '674316-001',
    'FCMHH0CQW7713X',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    415,
    'LOGITECH',
    'M185',
    '2115LZX6FCW8',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    416,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-04G-095C',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    417,
    'LOGITECH',
    'M185',
    '2044LZMCVQ78',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    418,
    'DELL',
    'WM118',
    'CN-0J5K9F-LO300-0CS-M227-A01',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    420,
    'LOGITECH',
    'M100',
    '2228HS04NH38',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    421,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-29K-04TO',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    423,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-0A9-0F5N',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    424,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-29K-03I0',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    425,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-0C7-0DEI',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    426,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-0AE-084Z',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    427,
    'LOGITECH',
    'M185',
    '2215LZX0PRE8',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    428,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-34I-06MU',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    429,
    'DELL',
    'MS116T1',
    'CN-01KMDJ-LO300-275-M13C',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    430,
    'DELL',
    'E1916HF',
    'CN-0XJ5TR-72872-69O-C9VB-A00',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    431,
    'DELL',
    'E2020H',
    'CN-08RWX5-QDC00-0C1-06LI-A03',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    432,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-73S-A23I-A00',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    433,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-6BR-A0AB-A00',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    434,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-69O-C9RB-A00',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    435,
    'DELL',
    'E2016HV',
    'CN-07XJH5-FCC00-195-ACUI-A14',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    436,
    'DELL',
    'E1916HV',
    'CN-0HN22V-FCC00-09C-C4RD-A13',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    437,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-7AF-DP6B-A01',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    439,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-73S-A26I-A00',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    440,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-777-CLJD-A00',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    441,
    'Generico',
    'PC-0044819',
    'L339044819',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    442,
    'LOGITECH',
    'M-U0026',
    '810-002182/HS202HB',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    445,
    'LOGITECH',
    'M110s',
    '2210HS09JD28',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    446,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-0AH-08ZE',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    448,
    'LOGITECH',
    'M100',
    '2228HS04QEV8',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    449,
    'DELL',
    'MS116t1',
    'CN-065K5F-LO300-0C2-08FZ',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    450,
    'LOGITECH',
    'M110s',
    '2351HS043V28',
    5,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    451,
    'DELL',
    'E2225HS',
    'CN-01HRFC-FCC00-48J-C8WX-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    452,
    'DELL',
    'E2223HN',
    'CN-01FTF8-FCC00-31T-C16X-A03',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    453,
    'DELL',
    'F9ZL292',
    'CN-0XJ5TR-72872-6A6-FKUB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    454,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-73S-A08I-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    455,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-6A6-FLUB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    456,
    'DELL',
    'P2018H',
    'CN-0RYK5R-TV200-132-0WHU-A13',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    457,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-8AF-FN5B-A06',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    458,
    'SAMSUNG',
    'S22F355FH',
    'ZZR3H4TK202746T',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    459,
    'DELL',
    'P2018H',
    'CN-0RYK5R-TV200-135-0Z3U-A13',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    460,
    'DELL',
    'P2018H',
    'CN-0RYK5R-TV200-133-038U-A13',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    461,
    'DELL',
    'E2222HS',
    'CN-0R5J65-FCC00-ABC-D2LX-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    462,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-69K-AMHB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    463,
    'DELL',
    'E2222HS',
    'CN-0WNYC5-FCC00-414-C0DX-A05',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    465,
    'DELL',
    'E1914Hc',
    'CN-04FF47-64180-47T-0JKU-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    466,
    'DELL',
    'E1914Hc',
    'CN-04FF47-64180-47T-0JKU',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    467,
    'DELL',
    'E2222H',
    'CN-0MVCKH-FCC00-312-M3AX-A03',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    468,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-67T-AG4B-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    469,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-6A6-F9CB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    470,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-6A6-FLKB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    471,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-67T-AG5B-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    473,
    'DELL',
    'E1916HV',
    'CN-0HN22V-FCC00-09C-C4VD-A13',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    474,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-944-DTPB-A07',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    475,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-85G-AVWB-A06',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    476,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-95S-DAUB-A07',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    477,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-69K-ALRB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    478,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-73S-A0PI-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    479,
    'LG',
    '17MB15T0',
    '701NTLEB3032',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    480,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-6A6-F9DB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    481,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-73S-A0JI-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    482,
    'DELL',
    'P2018H',
    'CN-0RYK5R-TV200-13B-0GVU-A13',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    483,
    'ASUS',
    'VP28U',
    'M2LMTF145984',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    484,
    'DELL',
    'E2020H',
    'CN-08RWX5-QDC00-0C1-067I-A03',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    485,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-9ALA2TU-A09',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    486,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-76F-C0FB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    487,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-96J-D63D-A07',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    488,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-69O-C9DB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    489,
    'DELL',
    'E2016HV',
    'CN-07XJH5-FCC00-18M-CKGI-A14',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    490,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-6A6-F9AB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    491,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-668-EJ0U-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    492,
    'DELL',
    'E2223HV',
    'CN-0R5J65-FCC00-22J-E3LX-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  );
INSERT INTO
  `devices` (
    `id`,
    `brand`,
    `model`,
    `serial_number`,
    `category_id`,
    `group_id`,
    `status`,
    `details`,
    `func`,
    `is_new`
  )
VALUES
  (
    493,
    'DELL',
    'E1916H',
    'CN-0XJTR-FCC00-9AL-A2TU-A09',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    494,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-69O-C13B-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    495,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-6A6-F7TB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    496,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-73S-A0LI-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    497,
    'ASUS',
    'VP28U',
    'M2LMTF146933',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    498,
    'DELL',
    'E1910Hc',
    'CN-0D176P-64180-96U-0EDU',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    499,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-69O-C9LB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    500,
    'DELL',
    'E2020H',
    'CN-08RWX5-QDC00-0C1-06KI-A03',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    501,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-69O-CAVB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    502,
    'DELL',
    'E2020H',
    'CN-08RWX5-QDC00-0C1-06AI-A03',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    503,
    'DELL',
    'E2020H',
    'CN-08RWX5-QDC00-0AU-35BI-A03',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    504,
    'DELL',
    'INSPIRON 5400',
    'INCLUIDO ALL IN ONE',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    506,
    'DELL',
    'E2020H',
    'CN-08RWX5-QDC00-0AE-1K6I-A03',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    507,
    'DELL',
    'E2222HS',
    'CN-0WMYC5-FCC00-414-C09X-A05',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    508,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-9AL-A2YU-A09',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    509,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-69K-AREB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    510,
    'DELL',
    'E2222HS',
    'CN-0WMYC5-FCC00-414-C0HX-A05',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    511,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-73S-A24I-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    512,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-9AL-A3MU-A09',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    513,
    'DELL',
    'E2222H',
    'CN-0MVCKH-FCC00-312-M3PX-A03',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    514,
    'DELL',
    'E2223HN',
    'CN-01FTF8-FCC00-328-A24X-A03',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    523,
    'LG',
    '17MB15TO',
    '703NTVS6Q423',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    524,
    'LENOVO',
    'LT1953',
    'V1X0889',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    525,
    'DELL',
    'E2222HS',
    'CN-0WMYC5-FCC003B8-CUTX-A05',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    526,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-884-ARGB-A06',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    527,
    'DELL',
    'E1916Hf',
    'CN-0XJ5TR-72872-69O-C9UB-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    528,
    'LG',
    '17MB15T0',
    '706NTKF4G325',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    529,
    'DELL',
    'P2018h',
    'CN-0RYK5R-TV200-133-1H1U-A13',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    530,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-FCC00-7A6-D22B-A01',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    531,
    'DELL',
    'E1916H',
    'CN-0XJ5TR-72872-73S-A2DI-A00',
    6,
    NULL,
    1,
    '',
    'resguardo',
    0
  ),(
    532,
    'LOGITECH',
    'K220',
    '2429SC101UL8',
    8,
    NULL,
    1,
    'KIT MOUSE Y TECLADO UN SOLO USB, MODELO DEL MOUSE M150',
    'asignado',
    0
  ),(
    533,
    'DELL',
    'E2225HS',
    'CN-01HRFC-FCC00-4B6-F6EX-A00',
    6,
    NULL,
    1,
    NULL,
    'asignado',
    0
  ),(
    534,
    'LOGITECH',
    'M185',
    '2217LZX5GY28',
    5,
    NULL,
    1,
    NULL,
    'resguardo',
    0
  ),(
    535,
    'DELL',
    'E2225HS',
    'CN-01HRFC-FCC00-48J-C8GX-A00',
    6,
    NULL,
    1,
    NULL,
    'asignado',
    0
  ),(
    536,
    'tp-link Omada',
    'EAP660 HD',
    '2243586000335',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    537,
    'tp-link Omada',
    'EAP660 HD',
    '22383C5000657',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    538,
    'tp-link Omada',
    'EAP660 HD',
    '22475N7000411',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    539,
    'tp-link Omada',
    'EAP660 HD',
    '22475N7000922',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    540,
    'tp-link Omada',
    'EAP660 HD',
    '22475N7000868',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    541,
    'tp-link Omada',
    'EAP660 HD',
    '224B121000790',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    542,
    'tp-link Omada',
    'EAP660 HD',
    '2243586000763',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    543,
    'tp-link Omada',
    'EAP660 HD',
    '22475N7000876',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    544,
    'tp-link Omada',
    'EAP660 HD',
    '22383C5000665',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    545,
    'tp-link Omada',
    'EAP660 HD',
    '22383C5000664',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    546,
    'tp-link Omada',
    'EAP660 HD',
    '22444L8000107',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    547,
    'tp-link Omada',
    'EAP660 HD',
    '22392Q5000622',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    548,
    'tp-link Omada',
    'EAP660 HD',
    '224B121001020',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    549,
    'tp-link Omada',
    'EAP660 HD',
    '2243586000029',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    550,
    'tp-link Omada',
    'EAP660 HD',
    '222C9L5000480',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    551,
    'tp-link Omada',
    'EAP660 HD',
    '22444L8000771',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    552,
    'tp-link Omada',
    'EAP660 HD',
    '223B0Q3000477',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    553,
    'tp-link Omada',
    'EAP660 HD',
    '2243586000147',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    554,
    'tp-link Omada',
    'EAP660 HD',
    '2243586000284',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    555,
    'tp-link Omada',
    'EAP660 HD',
    '2243586000996',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  ),(
    556,
    'tp-link Omada',
    'EAP660 HD',
    '2243586000564',
    13,
    NULL,
    1,
    '',
    'asignado',
    0
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: floors
# ------------------------------------------------------------

INSERT INTO
  `floors` (`id`, `name`, `description`, `status`)
VALUES
  (1, 'Planta Baja', 'Planta Baja', 1),(2, 'Piso 1', 'Quirofano y terapias', 1),(3, 'Piso 2', 'Hospitalizacion', 1),(4, 'Piso 3', 'Gobierno Piso 3', 1),(5, 'Piso 4', 'Archivo clunico y banco de sangre', 1),(6, 'SOTANO', 'Estacionamiento y bodegas', 1);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: mantenimiento_documentos
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: mantenimientos
# ------------------------------------------------------------

INSERT INTO
  `mantenimientos` (
    `id`,
    `responsiva_id`,
    `fecha`,
    `descripcion_falla`,
    `descripcion_solucion`,
    `user_id`,
    `folio`,
    `completo`
  )
VALUES
  (1, 16, '2026-01-29', '', '', 1, 'MAN-141', 1);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: movements
# ------------------------------------------------------------

INSERT INTO
  `movements` (
    `id`,
    `movement_time`,
    `affected_table`,
    `change_type`,
    `after_info`,
    `before_info`,
    `object_id`,
    `user_id`,
    `status`
  )
VALUES
  (
    1,
    '2025-08-07 03:51:27',
    'categories',
    1,
    '{\"name\":\"Desktop\",\"description\":\"Computadora de escritorio\",\"type\":0,\"status\":1}',
    'null',
    1,
    1,
    1
  ),(
    2,
    '2025-08-07 03:51:50',
    'custom_fields',
    1,
    '{\"name\":\"IP\",\"data_type\":\"text\",\"category_id\":1,\"required\":0,\"status\":1}',
    'null',
    1,
    1,
    1
  ),(
    3,
    '2025-08-07 03:51:57',
    'custom_fields',
    1,
    '{\"name\":\"DISCO\",\"data_type\":\"text\",\"category_id\":1,\"required\":0,\"status\":1}',
    'null',
    2,
    1,
    1
  ),(
    4,
    '2025-08-07 03:52:03',
    'custom_fields',
    1,
    '{\"name\":\"RAM\",\"data_type\":\"text\",\"category_id\":1,\"required\":0,\"status\":1}',
    'null',
    3,
    1,
    1
  ),(
    5,
    '2025-08-07 03:52:09',
    'custom_fields',
    3,
    'null',
    '{\"id\":3,\"name\":\"RAM\",\"data_type\":\"text\",\"category_id\":1,\"required\":0,\"status\":1}',
    3,
    1,
    1
  ),(
    6,
    '2025-08-07 03:52:17',
    'custom_fields',
    1,
    '{\"name\":\"MEMORIA\",\"data_type\":\"text\",\"category_id\":1,\"required\":0,\"status\":1}',
    'null',
    4,
    1,
    1
  ),(
    7,
    '2025-08-07 03:52:28',
    'custom_fields',
    1,
    '{\"name\":\"PROCESADOR\",\"data_type\":\"text\",\"category_id\":1,\"required\":0,\"status\":1}',
    'null',
    5,
    1,
    1
  ),(
    8,
    '2025-08-07 03:53:10',
    'categories',
    1,
    '{\"name\":\"Laptop\",\"description\":\"Computadora portatil\",\"type\":0,\"status\":1}',
    'null',
    2,
    1,
    1
  ),(
    9,
    '2025-08-07 03:53:18',
    'custom_fields',
    1,
    '{\"name\":\"IP\",\"data_type\":\"text\",\"category_id\":2,\"required\":0,\"status\":1}',
    'null',
    6,
    1,
    1
  ),(
    10,
    '2025-08-07 03:53:25',
    'custom_fields',
    3,
    'null',
    '{\"id\":6,\"name\":\"IP\",\"data_type\":\"text\",\"category_id\":2,\"required\":0,\"status\":1}',
    6,
    1,
    1
  ),(
    11,
    '2025-08-07 03:53:29',
    'custom_fields',
    1,
    '{\"name\":\"DISCO\",\"data_type\":\"text\",\"category_id\":2,\"required\":0,\"status\":1}',
    'null',
    7,
    1,
    1
  ),(
    12,
    '2025-08-07 03:53:39',
    'custom_fields',
    1,
    '{\"name\":\"PROCESADOR\",\"data_type\":\"text\",\"category_id\":2,\"required\":0,\"status\":1}',
    'null',
    8,
    1,
    1
  ),(
    13,
    '2025-08-07 03:53:47',
    'custom_fields',
    1,
    '{\"name\":\"RAM\",\"data_type\":\"text\",\"category_id\":2,\"required\":0,\"status\":1}',
    'null',
    9,
    1,
    1
  ),(
    14,
    '2025-08-07 03:55:04',
    'categories',
    1,
    '{\"name\":\"All in One\",\"description\":\"Computadora de escritorio todo en uno\",\"type\":0,\"status\":1}',
    'null',
    3,
    1,
    1
  ),(
    15,
    '2025-08-07 03:55:17',
    'custom_fields',
    1,
    '{\"name\":\"IP\",\"data_type\":\"text\",\"category_id\":3,\"required\":0,\"status\":1}',
    'null',
    10,
    1,
    1
  ),(
    16,
    '2025-08-07 03:55:37',
    'custom_fields',
    1,
    '{\"name\":\"DISCO\",\"data_type\":\"text\",\"category_id\":3,\"required\":0,\"status\":1}',
    'null',
    11,
    1,
    1
  ),(
    17,
    '2025-08-07 03:55:47',
    'custom_fields',
    1,
    '{\"name\":\"PROCESADOR\",\"data_type\":\"text\",\"category_id\":3,\"required\":0,\"status\":1}',
    'null',
    12,
    1,
    1
  ),(
    18,
    '2025-08-07 03:55:51',
    'custom_fields',
    1,
    '{\"name\":\"MEMORIA\",\"data_type\":\"text\",\"category_id\":3,\"required\":0,\"status\":1}',
    'null',
    13,
    1,
    1
  ),(
    19,
    '2025-08-07 03:56:17',
    'categories',
    1,
    '{\"name\":\"Teclado\",\"description\":\"Periferico de entrada\",\"type\":0,\"status\":1}',
    'null',
    4,
    1,
    1
  ),(
    20,
    '2025-08-07 03:56:28',
    'categories',
    1,
    '{\"name\":\"Mouse\",\"description\":\"Periferico de entrada\",\"type\":0,\"status\":1}',
    'null',
    5,
    1,
    1
  ),(
    21,
    '2025-08-07 03:56:54',
    'categories',
    1,
    '{\"name\":\"Monitor\",\"description\":\"Periferico de salida\",\"type\":0,\"status\":1}',
    'null',
    6,
    1,
    1
  ),(
    22,
    '2025-08-08 15:29:31',
    'departments',
    1,
    '{\"name\":\"Ivonne\",\"abbreviation\":\"FDDF\",\"description\":\"fdgdfgdfg\",\"department_head\":\"dfsdfs\",\"status\":1}',
    'null',
    40,
    1,
    1
  ),(
    23,
    '2025-08-08 15:30:34',
    'departments',
    3,
    'null',
    '{\"id\":40,\"name\":\"Ivonne\",\"abbreviation\":\"FDDF\",\"description\":\"fdgdfgdfg\",\"department_head\":\"dfsdfs\",\"status\":1}',
    40,
    1,
    1
  ),(
    24,
    '2025-08-08 15:30:57',
    'areas',
    3,
    'null',
    '{\"id\":96,\"name\":\"BANCO SANGRE\",\"description\":\"BANCO SANGRE\",\"status\":1,\"id_floor\":5}',
    96,
    1,
    1
  ),(
    25,
    '2025-08-08 15:32:29',
    'categories',
    1,
    '{\"name\":\"Consumibles\",\"description\":\"Toner\",\"type\":\"1\",\"status\":1}',
    'null',
    7,
    1,
    1
  ),(
    26,
    '2025-08-08 15:32:52',
    'accessories',
    1,
    '{\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":6,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    1,
    1,
    1
  ),(
    27,
    '2025-08-08 15:33:06',
    'accessories',
    1,
    '{\"brand\":\"Samsung\",\"product_name\":\"Imagen\",\"total\":5,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    2,
    1,
    1
  ),(
    28,
    '2025-08-08 15:33:40',
    'accessories',
    1,
    '{\"brand\":\"Samsung\",\"product_name\":\"Fusor 5433\",\"total\":4,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    3,
    1,
    1
  ),(
    29,
    '2025-08-08 15:33:41',
    'accessories',
    5,
    '{\"brand\":\"Samsung\",\"product_name\":\"Fusor 5433\",\"total\":3,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":3,\"brand\":\"Samsung\",\"product_name\":\"Fusor 5433\",\"total\":4,\"category_id\":7,\"details\":\"\",\"status\":1}',
    3,
    1,
    1
  ),(
    30,
    '2025-08-08 15:33:41',
    'accessories',
    5,
    '{\"brand\":\"Samsung\",\"product_name\":\"Fusor 5433\",\"total\":2,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":3,\"brand\":\"Samsung\",\"product_name\":\"Fusor 5433\",\"total\":3,\"category_id\":7,\"details\":\"\",\"status\":1}',
    3,
    1,
    1
  ),(
    31,
    '2025-08-08 15:33:41',
    'accessories',
    5,
    '{\"brand\":\"Samsung\",\"product_name\":\"Fusor 5433\",\"total\":1,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":3,\"brand\":\"Samsung\",\"product_name\":\"Fusor 5433\",\"total\":2,\"category_id\":7,\"details\":\"\",\"status\":1}',
    3,
    1,
    1
  ),(
    32,
    '2025-08-08 15:33:45',
    'accessories',
    5,
    '{\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":5,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":1,\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":6,\"category_id\":7,\"details\":\"\",\"status\":1}',
    1,
    1,
    1
  ),(
    33,
    '2025-08-08 15:33:46',
    'accessories',
    5,
    '{\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":4,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":1,\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":5,\"category_id\":7,\"details\":\"\",\"status\":1}',
    1,
    1,
    1
  ),(
    34,
    '2025-08-08 15:33:46',
    'accessories',
    5,
    '{\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":3,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":1,\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":4,\"category_id\":7,\"details\":\"\",\"status\":1}',
    1,
    1,
    1
  ),(
    35,
    '2025-08-08 15:33:46',
    'accessories',
    5,
    '{\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":2,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":1,\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":3,\"category_id\":7,\"details\":\"\",\"status\":1}',
    1,
    1,
    1
  ),(
    36,
    '2025-08-08 15:33:47',
    'accessories',
    5,
    '{\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":1,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":1,\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":2,\"category_id\":7,\"details\":\"\",\"status\":1}',
    1,
    1,
    1
  ),(
    37,
    '2025-08-08 15:33:47',
    'accessories',
    5,
    '{\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":0,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":1,\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":1,\"category_id\":7,\"details\":\"\",\"status\":1}',
    1,
    1,
    1
  ),(
    38,
    '2025-08-08 15:38:52',
    'users',
    1,
    '{\"nombre\":\"Brayham\",\"apellidos\":\"Pavon Martell\",\"usuario\":\"pmbrian\",\"rol\":\"1\"}',
    'null',
    2,
    1,
    1
  ),(
    39,
    '2025-08-08 15:41:04',
    'devices',
    1,
    '{\"brand\":\"LOGITECH\",\"model\":\"K220\",\"serial_number\":\"2429SC101UL8\",\"category_id\":\"4\",\"group_id\":null,\"status\":1,\"details\":\"KIT MOUSE Y TECLADO UN SOLO USB \",\"is_new\":1}',
    'null',
    532,
    1,
    1
  ),(
    40,
    '2025-08-08 15:42:39',
    'categories',
    1,
    '{\"name\":\"KIT MOUSE Y TECLADO\",\"description\":\"MOUSE Y TECLADO A UN MISMO USB\",\"type\":0,\"status\":1}',
    'null',
    8,
    1,
    1
  ),(
    41,
    '2025-08-08 15:45:31',
    'devices',
    2,
    '{\"id\":532,\"brand\":\"LOGITECH\",\"model\":\"K220\",\"serial_number\":\"2429SC101UL8\",\"category_id\":8,\"group_id\":null,\"status\":1,\"details\":\"KIT MOUSE Y TECLADO UN SOLO USB, MODELO DEL MOUSE M150\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":532,\"brand\":\"LOGITECH\",\"model\":\"K220\",\"serial_number\":\"2429SC101UL8\",\"category_id\":4,\"group_id\":null,\"status\":1,\"details\":\"KIT MOUSE Y TECLADO UN SOLO USB \",\"func\":\"resguardo\",\"is_new\":1}',
    532,
    1,
    1
  ),(
    42,
    '2025-08-08 15:48:30',
    'responsivas',
    1,
    '{\"folio\":\"SIS-134\",\"fecha\":\"2025-08-08\",\"responsable\":\"Brayham Pavon Martell\",\"id_area\":88,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[532,2]}',
    'null',
    1,
    1,
    1
  ),(
    43,
    '2025-08-08 16:24:24',
    'responsivas',
    1,
    '{\"folio\":\"SIS-135\",\"fecha\":\"2025-08-08\",\"responsable\":\"Jesus Antonio Chavez Fabian \",\"id_area\":86,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[259]}',
    'null',
    2,
    1,
    1
  ),(
    44,
    '2025-08-08 16:31:36',
    'accessories',
    3,
    'null',
    '{\"id\":1,\"brand\":\"HP\",\"product_name\":\"Toner 4567\",\"total\":0,\"category_id\":7,\"details\":\"\",\"status\":1}',
    1,
    1,
    1
  ),(
    45,
    '2025-08-08 16:31:38',
    'accessories',
    3,
    'null',
    '{\"id\":2,\"brand\":\"Samsung\",\"product_name\":\"Imagen\",\"total\":5,\"category_id\":7,\"details\":\"\",\"status\":1}',
    2,
    1,
    1
  ),(
    46,
    '2025-08-08 16:31:40',
    'accessories',
    3,
    'null',
    '{\"id\":3,\"brand\":\"Samsung\",\"product_name\":\"Fusor 5433\",\"total\":1,\"category_id\":7,\"details\":\"\",\"status\":1}',
    3,
    1,
    1
  ),(
    47,
    '2025-08-08 16:31:50',
    'categories',
    3,
    'null',
    '{\"id\":7,\"name\":\"Consumibles\",\"description\":\"Toner\",\"type\":1,\"status\":1}',
    7,
    1,
    1
  ),(
    48,
    '2025-08-08 16:35:37',
    'devices',
    1,
    '{\"brand\":\"DELL\",\"model\":\"E2225HS\",\"serial_number\":\"CN-01HRFC-FCC00-4B6-F6EX-A00\",\"category_id\":\"6\",\"group_id\":null,\"status\":1,\"details\":null,\"is_new\":1}',
    'null',
    533,
    1,
    1
  ),(
    49,
    '2025-08-08 16:37:26',
    'responsivas',
    1,
    '{\"folio\":\"SIS-136\",\"fecha\":\"2025-08-08\",\"responsable\":\"Juan Carlos Monroy\",\"id_area\":85,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[533,268]}',
    'null',
    3,
    1,
    1
  ),(
    50,
    '2025-08-08 16:43:31',
    'devices',
    1,
    '{\"brand\":\"LOGITECH\",\"model\":\"M185\",\"serial_number\":\"2217LZX5GY28\",\"category_id\":\"5\",\"group_id\":null,\"status\":1,\"details\":null,\"is_new\":1}',
    'null',
    534,
    1,
    1
  ),(
    51,
    '2025-08-08 17:02:45',
    'users',
    1,
    '{\"nombre\":\"Arlette Ivonne\",\"apellidos\":\"López Espino\",\"usuario\":\"Ivonne\",\"rol\":\"2\"}',
    'null',
    3,
    2,
    1
  ),(
    54,
    '2025-08-08 17:11:15',
    'categories',
    4,
    '{\"id\":7,\"name\":\"Consumibles\",\"description\":\"Toner\",\"type\":1,\"status\":1}',
    '{\"id\":7,\"name\":\"Consumibles\",\"description\":\"Toner\",\"type\":1,\"status\":0}',
    7,
    1,
    1
  ),(
    55,
    '2025-08-08 17:11:38',
    'categories',
    2,
    '{\"name\":\"Consumibles\",\"description\":\"Tóner, unidad de imagen, fusor\",\"type\":1}',
    '{\"id\":7,\"name\":\"Consumibles\",\"description\":\"Toner\",\"type\":1,\"status\":1}',
    7,
    1,
    1
  ),(
    56,
    '2025-08-08 17:13:31',
    'accessories',
    1,
    '{\"brand\":\"TK-1175 KYOCERA\",\"product_name\":\"TONER KIT BLACK\",\"total\":3,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    4,
    1,
    1
  ),(
    57,
    '2025-08-08 17:14:16',
    'accessories',
    1,
    '{\"brand\":\"TK-3402 KYOCERA\",\"product_name\":\"TONER KIT BLACK\",\"total\":1,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    5,
    1,
    1
  ),(
    58,
    '2025-08-08 17:15:02',
    'accessories',
    1,
    '{\"brand\":\"TK-3402\",\"product_name\":\"TONER KIT MAGNETA\",\"total\":1,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    6,
    1,
    1
  ),(
    59,
    '2025-08-08 17:15:41',
    'accessories',
    1,
    '{\"brand\":\"TK-5372Y\",\"product_name\":\"TONER KIT YELLOW\",\"total\":2,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    7,
    1,
    1
  ),(
    60,
    '2025-08-08 17:16:10',
    'accessories',
    1,
    '{\"brand\":\"TK-5372C\",\"product_name\":\"TONER KIT CIAN\",\"total\":1,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    8,
    1,
    1
  ),(
    61,
    '2025-08-08 17:16:51',
    'accessories',
    1,
    '{\"brand\":\"TK-5372K\",\"product_name\":\"TONER KIT BLACK\",\"total\":2,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    9,
    1,
    1
  ),(
    62,
    '2025-08-08 17:17:49',
    'accessories',
    1,
    '{\"brand\":\"TK-3432\",\"product_name\":\"TONER KIT BLACK\",\"total\":2,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    10,
    1,
    1
  ),(
    63,
    '2025-08-08 17:24:39',
    'accessories',
    1,
    '{\"brand\":\"303E SAMSUNG\",\"product_name\":\"TONER BLACK\",\"total\":2,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    11,
    1,
    1
  ),(
    64,
    '2025-08-08 17:27:10',
    'accessories',
    1,
    '{\"brand\":\"JC91-01023A \",\"product_name\":\"FUSOR HP\",\"total\":1,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    12,
    1,
    1
  ),(
    65,
    '2025-08-08 17:30:50',
    'accessories',
    1,
    '{\"brand\":\"MLT-D203U\",\"product_name\":\"TONER\",\"total\":1,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    13,
    1,
    1
  ),(
    66,
    '2025-08-08 17:32:12',
    'accessories',
    1,
    '{\"brand\":\"MLT-D201L SAMSUNG\",\"product_name\":\"TONER\",\"total\":1,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    14,
    1,
    1
  ),(
    67,
    '2025-08-08 17:32:55',
    'accessories',
    2,
    '{\"brand\":\"MLT-D203U SAMSUNG\",\"product_name\":\"TONER\",\"total\":1,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":13,\"brand\":\"MLT-D203U\",\"product_name\":\"TONER\",\"total\":1,\"category_id\":7,\"details\":\"\",\"status\":1}',
    13,
    1,
    1
  ),(
    68,
    '2025-08-08 17:34:10',
    'accessories',
    1,
    '{\"brand\":\"MLT-R303/SEE HP\",\"product_name\":\"TAMBOR DE TRANSFERENCIA DE IMAGEANES\",\"total\":1,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    15,
    1,
    1
  ),(
    69,
    '2025-08-08 17:34:23',
    'accessories',
    2,
    '{\"brand\":\"MLT-R303/SEE HP\",\"product_name\":\"TAMBOR DE TRANSFERENCIA DE IMAGENES\",\"total\":1,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":15,\"brand\":\"MLT-R303/SEE HP\",\"product_name\":\"TAMBOR DE TRANSFERENCIA DE IMAGEANES\",\"total\":1,\"category_id\":7,\"details\":\"\",\"status\":1}',
    15,
    1,
    1
  ),(
    70,
    '2025-08-08 17:35:53',
    'accessories',
    1,
    '{\"brand\":\"MLT-D358S\",\"product_name\":\"TONER \",\"total\":1,\"category_id\":\"7\",\"details\":\"\"}',
    'null',
    16,
    1,
    1
  ),(
    71,
    '2025-08-08 17:36:14',
    'accessories',
    2,
    '{\"brand\":\"JC91-01023A \",\"product_name\":\"FUSOR\",\"total\":1,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":12,\"brand\":\"JC91-01023A \",\"product_name\":\"FUSOR HP\",\"total\":1,\"category_id\":7,\"details\":\"\",\"status\":1}',
    12,
    1,
    1
  ),(
    72,
    '2025-08-08 17:49:25',
    'categories',
    1,
    '{\"name\":\"Mantenimiento \",\"description\":\"Latas, trapos\",\"type\":\"1\",\"status\":1}',
    'null',
    9,
    1,
    1
  ),(
    73,
    '2025-08-08 17:50:40',
    'accessories',
    1,
    '{\"brand\":\"SILIMEX\",\"product_name\":\"ESPUMA LIMPIADORA\",\"total\":5,\"category_id\":\"9\",\"details\":\"\"}',
    'null',
    17,
    1,
    1
  ),(
    74,
    '2025-08-08 17:51:31',
    'accessories',
    1,
    '{\"brand\":\"SILIMEX\",\"product_name\":\"LIMPIADOR DE PANTALLAS\",\"total\":2,\"category_id\":\"9\",\"details\":\"\"}',
    'null',
    18,
    1,
    1
  ),(
    75,
    '2025-08-08 17:52:14',
    'accessories',
    1,
    '{\"brand\":\"PROLICOM\",\"product_name\":\"AIRE COMPRIMIDO\",\"total\":5,\"category_id\":\"9\",\"details\":\"\"}',
    'null',
    19,
    1,
    1
  ),(
    76,
    '2025-08-08 17:53:53',
    'accessories',
    1,
    '{\"brand\":\"3M\",\"product_name\":\"TRAPOS\",\"total\":9,\"category_id\":\"9\",\"details\":\"ROJOS, AZULES\"}',
    'null',
    20,
    1,
    1
  ),(
    77,
    '2025-08-08 17:55:23',
    'categories',
    1,
    '{\"name\":\"Cámaras\",\"description\":\"Cámara de video\",\"type\":\"1\",\"status\":1}',
    'null',
    10,
    1,
    1
  ),(
    78,
    '2025-08-08 17:57:37',
    'accessories',
    1,
    '{\"brand\":\"HILOOK IPC-T240H\",\"product_name\":\"CAMARA IP\",\"total\":1,\"category_id\":\"10\",\"details\":\"\"}',
    'null',
    21,
    1,
    1
  ),(
    79,
    '2025-08-08 17:58:25',
    'accessories',
    1,
    '{\"brand\":\"HILOOK H.265+\",\"product_name\":\"CAMARA IP\",\"total\":4,\"category_id\":\"10\",\"details\":\"\"}',
    'null',
    22,
    1,
    1
  ),(
    80,
    '2025-08-08 17:59:14',
    'accessories',
    2,
    '{\"brand\":\"HILOOK H.265+\",\"product_name\":\"CAMARA IP\",\"total\":5,\"category_id\":10,\"details\":\"1 Cámara bloqueada\"}',
    '{\"id\":22,\"brand\":\"HILOOK H.265+\",\"product_name\":\"CAMARA IP\",\"total\":4,\"category_id\":10,\"details\":\"\",\"status\":1}',
    22,
    1,
    1
  ),(
    81,
    '2025-08-08 18:00:43',
    'categories',
    1,
    '{\"name\":\"Insumos\",\"description\":\"Paquetes de piezas\",\"type\":\"1\",\"status\":1}',
    'null',
    11,
    1,
    1
  ),(
    82,
    '2025-08-08 18:03:07',
    'accessories',
    1,
    '{\"brand\":\"Cat 5e Linkedpro\",\"product_name\":\"RJ-45 \",\"total\":100,\"category_id\":\"11\",\"details\":\"Conector de chapa de oro a 30 micras\"}',
    'null',
    23,
    1,
    1
  ),(
    83,
    '2025-08-08 18:05:02',
    'accessories',
    4,
    '{\"brand\":\"303E SAMSUNG\",\"product_name\":\"TONER BLACK\",\"total\":3,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":11,\"brand\":\"303E SAMSUNG\",\"product_name\":\"TONER BLACK\",\"total\":2,\"category_id\":7,\"details\":\"\",\"status\":1}',
    11,
    1,
    1
  ),(
    84,
    '2025-08-08 18:05:24',
    'accessories',
    4,
    '{\"brand\":\"303E SAMSUNG\",\"product_name\":\"TONER BLACK\",\"total\":4,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":11,\"brand\":\"303E SAMSUNG\",\"product_name\":\"TONER BLACK\",\"total\":3,\"category_id\":7,\"details\":\"\",\"status\":1}',
    11,
    1,
    1
  ),(
    85,
    '2025-08-08 18:05:55',
    'accessories',
    5,
    '{\"brand\":\"303E SAMSUNG\",\"product_name\":\"TONER BLACK\",\"total\":4,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":11,\"brand\":\"303E SAMSUNG\",\"product_name\":\"TONER BLACK\",\"total\":4,\"category_id\":7,\"details\":\"\",\"status\":1}',
    11,
    1,
    1
  ),(
    86,
    '2025-08-08 18:10:34',
    'devices',
    1,
    '{\"brand\":\"DELL\",\"model\":\"E2225HS\",\"serial_number\":\"CN-01HRFC-FCC00-48J-C8GX-A00\",\"category_id\":\"6\",\"group_id\":null,\"status\":1,\"details\":null,\"is_new\":1}',
    'null',
    535,
    1,
    1
  ),(
    87,
    '2025-08-08 18:12:16',
    'areas',
    1,
    '{\"name\":\"SITE\",\"description\":\"Ubicacion del MDF\",\"id_floor\":\"1\"}',
    'null',
    102,
    1,
    1
  ),(
    88,
    '2025-08-08 18:14:06',
    'responsivas',
    1,
    '{\"folio\":\"SIS-137\",\"fecha\":\"2025-08-08\",\"responsable\":\"Juan Carlos Monroy\",\"id_area\":102,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[535,253]}',
    'null',
    4,
    1,
    1
  ),(
    89,
    '2025-08-08 18:34:35',
    'accessories',
    1,
    '{\"brand\":\"SILIMEX\",\"product_name\":\"LIMPIADOR DE CIRCUITOS\",\"total\":1,\"category_id\":\"9\",\"details\":\"\"}',
    'null',
    24,
    1,
    1
  ),(
    90,
    '2025-08-08 18:36:36',
    'accessories',
    1,
    '{\"brand\":\"DIVERSEY\",\"product_name\":\"GEL DESINFECTANTE\",\"total\":1,\"category_id\":\"9\",\"details\":\"946 ML\\nCADUCIDAD: 15 FEB 2026\"}',
    'null',
    25,
    1,
    1
  ),(
    91,
    '2025-08-08 23:58:57',
    'accessories',
    4,
    '{\"brand\":\"SILIMEX\",\"product_name\":\"LIMPIADOR DE CIRCUITOS\",\"total\":2,\"category_id\":9,\"details\":\"\"}',
    '{\"id\":24,\"brand\":\"SILIMEX\",\"product_name\":\"LIMPIADOR DE CIRCUITOS\",\"total\":1,\"category_id\":9,\"details\":\"\",\"status\":1}',
    24,
    1,
    1
  ),(
    92,
    '2025-08-08 23:58:58',
    'accessories',
    5,
    '{\"brand\":\"SILIMEX\",\"product_name\":\"LIMPIADOR DE CIRCUITOS\",\"total\":1,\"category_id\":9,\"details\":\"\"}',
    '{\"id\":24,\"brand\":\"SILIMEX\",\"product_name\":\"LIMPIADOR DE CIRCUITOS\",\"total\":2,\"category_id\":9,\"details\":\"\",\"status\":1}',
    24,
    1,
    1
  ),(
    93,
    '2025-08-08 23:59:22',
    'accessories',
    4,
    '{\"brand\":\"HILOOK IPC-T240H\",\"product_name\":\"CAMARA IP\",\"total\":1.5,\"category_id\":10,\"details\":\"\"}',
    '{\"id\":21,\"brand\":\"HILOOK IPC-T240H\",\"product_name\":\"CAMARA IP\",\"total\":1,\"category_id\":10,\"details\":\"\",\"status\":1}',
    21,
    1,
    1
  ),(
    94,
    '2025-08-08 23:59:30',
    'accessories',
    5,
    '{\"brand\":\"HILOOK IPC-T240H\",\"product_name\":\"CAMARA IP\",\"total\":1,\"category_id\":10,\"details\":\"\"}',
    '{\"id\":21,\"brand\":\"HILOOK IPC-T240H\",\"product_name\":\"CAMARA IP\",\"total\":2,\"category_id\":10,\"details\":\"\",\"status\":1}',
    21,
    1,
    1
  ),(
    95,
    '2025-08-09 00:06:26',
    'categories',
    1,
    '{\"name\":\"Herramientas\",\"description\":\"Herramientas varias\",\"type\":\"1\",\"status\":1}',
    'null',
    12,
    1,
    1
  ),(
    96,
    '2025-08-09 00:07:11',
    'accessories',
    1,
    '{\"brand\":\"GR Perlec\",\"product_name\":\"BROCHAS\",\"total\":2,\"category_id\":\"12\",\"details\":\"Brocha chica y grande (rojas)\"}',
    'null',
    26,
    1,
    1
  ),(
    97,
    '2025-08-09 00:08:00',
    'accessories',
    1,
    '{\"brand\":\"VARIAS\",\"product_name\":\"PINZAS PONCHADORAS\",\"total\":2,\"category_id\":\"12\",\"details\":\"Pinza amarilla FLUKE netwoks\\nPinza verde Commercial Electric\"}',
    'null',
    27,
    1,
    1
  ),(
    98,
    '2025-08-09 00:08:21',
    'accessories',
    1,
    '{\"brand\":\"TRUPER\",\"product_name\":\"PINZAS DE ELECTRICISTA\",\"total\":1,\"category_id\":\"12\",\"details\":\"\"}',
    'null',
    28,
    1,
    1
  ),(
    99,
    '2025-08-14 17:13:20',
    'categories',
    1,
    '{\"name\":\"AP\",\"description\":\"Access point\",\"type\":0,\"status\":1}',
    'null',
    13,
    1,
    1
  ),(
    100,
    '2025-08-14 17:13:43',
    'custom_fields',
    1,
    '{\"name\":\"MAC\",\"data_type\":\"text\",\"category_id\":13,\"required\":1,\"status\":1}',
    'null',
    14,
    1,
    1
  ),(
    101,
    '2025-08-14 17:14:02',
    'custom_fields',
    1,
    '{\"name\":\"DEVICE KEY\",\"data_type\":\"text\",\"category_id\":13,\"required\":0,\"status\":1}',
    'null',
    15,
    1,
    1
  ),(
    102,
    '2025-08-14 17:14:15',
    'custom_fields',
    1,
    '{\"name\":\"PUERTO\",\"data_type\":\"text\",\"category_id\":13,\"required\":0,\"status\":1}',
    'null',
    16,
    1,
    1
  );
INSERT INTO
  `movements` (
    `id`,
    `movement_time`,
    `affected_table`,
    `change_type`,
    `after_info`,
    `before_info`,
    `object_id`,
    `user_id`,
    `status`
  )
VALUES
  (
    103,
    '2025-08-14 17:15:36',
    'accessories',
    5,
    '{\"brand\":\"MLT-R303/SEE HP\",\"product_name\":\"TAMBOR DE TRANSFERENCIA DE IMAGENES\",\"total\":0,\"category_id\":7,\"details\":\"\"}',
    '{\"id\":15,\"brand\":\"MLT-R303/SEE HP\",\"product_name\":\"TAMBOR DE TRANSFERENCIA DE IMAGENES\",\"total\":1,\"category_id\":7,\"details\":\"\",\"status\":1}',
    15,
    1,
    1
  ),(
    104,
    '2025-08-14 18:20:58',
    'areas',
    1,
    '{\"name\":\"Descanso Medicos\",\"description\":\"Dentro de quirofano, area de descanso de medicos\",\"id_floor\":\"3\"}',
    'null',
    103,
    1,
    1
  ),(
    105,
    '2025-08-14 18:22:32',
    'devices',
    2,
    '{\"id\":536,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000335\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":536,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000335\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    536,
    1,
    1
  ),(
    106,
    '2025-08-14 18:23:47',
    'areas',
    2,
    '{\"id\":103,\"name\":\"Descanso Medicos\",\"description\":\"Dentro de quirofano, area de descanso de medicos\",\"status\":1,\"id_floor\":2}',
    '{\"id\":103,\"name\":\"Descanso Medicos\",\"description\":\"Dentro de quirofano, area de descanso de medicos\",\"status\":1,\"id_floor\":3}',
    103,
    1,
    1
  ),(
    107,
    '2025-08-14 18:24:27',
    'areas',
    2,
    '{\"id\":103,\"name\":\"DESCANSO MEDICOS\",\"description\":\"Dentro de quirofano, area de descanso de medicos\",\"status\":1,\"id_floor\":2}',
    '{\"id\":103,\"name\":\"Descanso Medicos\",\"description\":\"Dentro de quirofano, area de descanso de medicos\",\"status\":1,\"id_floor\":2}',
    103,
    1,
    1
  ),(
    108,
    '2025-08-14 18:25:08',
    'responsivas',
    1,
    '{\"folio\":\"SIS-138\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":103,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[536]}',
    'null',
    5,
    1,
    1
  ),(
    109,
    '2025-08-14 18:26:32',
    'devices',
    2,
    '{\"id\":537,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22383C5000657\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":537,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22383C5000657\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    537,
    1,
    1
  ),(
    110,
    '2025-08-14 18:29:13',
    'devices',
    2,
    '{\"id\":538,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22475N7000411\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":538,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22475N7000411\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    538,
    1,
    1
  ),(
    111,
    '2025-08-14 18:29:56',
    'devices',
    2,
    '{\"id\":539,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22475N7000922\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":539,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22475N7000922\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    539,
    1,
    1
  ),(
    112,
    '2025-08-14 18:32:28',
    'devices',
    2,
    '{\"id\":540,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22475N7000868\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":540,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22475N7000868\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    540,
    1,
    1
  ),(
    113,
    '2025-08-14 18:32:56',
    'devices',
    2,
    '{\"id\":541,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"224B121000790\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":541,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"224B121000790\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    541,
    1,
    1
  ),(
    114,
    '2025-08-14 18:34:08',
    'devices',
    2,
    '{\"id\":542,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000763\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":542,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000763\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    542,
    1,
    1
  ),(
    115,
    '2025-08-14 18:34:57',
    'devices',
    2,
    '{\"id\":543,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22475N7000876\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":543,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22475N7000876\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    543,
    1,
    1
  ),(
    116,
    '2025-08-14 18:35:32',
    'devices',
    2,
    '{\"id\":544,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22383C5000665\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":544,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22383C5000665\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    544,
    1,
    1
  ),(
    117,
    '2025-08-14 18:36:12',
    'devices',
    2,
    '{\"id\":545,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22383C5000664\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":545,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22383C5000664\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    545,
    1,
    1
  ),(
    118,
    '2025-08-14 18:36:35',
    'devices',
    2,
    '{\"id\":546,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22444L8000107\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":546,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22444L8000107\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    546,
    1,
    1
  ),(
    119,
    '2025-08-14 18:37:00',
    'devices',
    2,
    '{\"id\":547,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22392Q5000622\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":547,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22392Q5000622\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    547,
    1,
    1
  ),(
    120,
    '2025-08-14 18:37:46',
    'devices',
    2,
    '{\"id\":548,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"224B121001020\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":548,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"224B121001020\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    548,
    1,
    1
  ),(
    121,
    '2025-08-14 18:38:10',
    'devices',
    2,
    '{\"id\":549,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000029\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":549,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000029\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    549,
    1,
    1
  ),(
    122,
    '2025-08-14 18:38:33',
    'devices',
    2,
    '{\"id\":550,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"222C9L5000480\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":550,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"222C9L5000480\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    550,
    1,
    1
  ),(
    123,
    '2025-08-14 18:39:14',
    'devices',
    2,
    '{\"id\":551,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22444L8000771\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":551,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"22444L8000771\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    551,
    1,
    1
  ),(
    124,
    '2025-08-14 18:39:42',
    'devices',
    2,
    '{\"id\":552,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"223B0Q3000477\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":552,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"223B0Q3000477\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    552,
    1,
    1
  ),(
    125,
    '2025-08-14 18:40:17',
    'devices',
    2,
    '{\"id\":553,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000147\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":553,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000147\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    553,
    1,
    1
  ),(
    126,
    '2025-08-14 18:40:47',
    'devices',
    2,
    '{\"id\":554,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000284\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":554,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000284\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    554,
    1,
    1
  ),(
    127,
    '2025-08-14 18:41:10',
    'devices',
    2,
    '{\"id\":555,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000996\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":555,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000996\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    555,
    1,
    1
  ),(
    128,
    '2025-08-14 18:41:34',
    'devices',
    2,
    '{\"id\":556,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000564\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":\"\",\"func\":\"resguardo\",\"is_new\":1}',
    '{\"id\":556,\"brand\":\"tp-link Omada\",\"model\":\"EAP660 HD\",\"serial_number\":\"2243586000564\",\"category_id\":13,\"group_id\":null,\"status\":1,\"details\":null,\"func\":\"resguardo\",\"is_new\":1}',
    556,
    1,
    1
  ),(
    129,
    '2025-08-14 18:57:03',
    'departments',
    2,
    '{\"name\":\"SUPERVISION ENFERMERIA\",\"abbreviation\":\"SUPE\",\"description\":\"SUPERVISION ENFERMERIA\",\"department_head\":\"Sin Asignar\"}',
    '{\"id\":25,\"name\":\"SUPERVISIN ENFERMERIA\",\"abbreviation\":\"SUPE\",\"description\":\"SUPERVISIN ENFERMERIA\",\"department_head\":\"Sin Asignar\",\"status\":1}',
    25,
    1,
    1
  ),(
    130,
    '2025-08-14 18:57:52',
    'departments',
    2,
    '{\"name\":\"ADMISION\",\"abbreviation\":\"ADM\",\"description\":\"ADMISION\",\"department_head\":\"Sin Asignar\"}',
    '{\"id\":13,\"name\":\"ADMISIN\",\"abbreviation\":\"ADM\",\"description\":\"ADMISIN\",\"department_head\":\"Sin Asignar\",\"status\":1}',
    13,
    1,
    1
  ),(
    131,
    '2025-08-14 18:58:02',
    'departments',
    2,
    '{\"name\":\"NUTRICION\",\"abbreviation\":\"NUT\",\"description\":\"NUTRICION\",\"department_head\":\"Sin Asignar\"}',
    '{\"id\":11,\"name\":\"NUTRICIN\",\"abbreviation\":\"NUT\",\"description\":\"NUTRICIN\",\"department_head\":\"Sin Asignar\",\"status\":1}',
    11,
    1,
    1
  ),(
    132,
    '2025-08-14 18:59:26',
    'areas',
    2,
    '{\"id\":19,\"name\":\"ADMISION URGENCIAS\",\"description\":\"ADMISION URGENCIAS\",\"status\":1,\"id_floor\":1}',
    '{\"id\":19,\"name\":\"ADMISIN URGENCIAS\",\"description\":\"ADMISIN URGENCIAS\",\"status\":1,\"id_floor\":1}',
    19,
    1,
    1
  ),(
    133,
    '2025-08-14 18:59:40',
    'areas',
    2,
    '{\"id\":26,\"name\":\"NUTRICION\",\"description\":\"NUTRICION\",\"status\":1,\"id_floor\":1}',
    '{\"id\":26,\"name\":\"NUTRICIN\",\"description\":\"NUTRICIN\",\"status\":1,\"id_floor\":1}',
    26,
    1,
    1
  ),(
    134,
    '2025-08-14 19:00:00',
    'areas',
    2,
    '{\"id\":34,\"name\":\"ADMISION 1\",\"description\":\"ADMISION 1\",\"status\":1,\"id_floor\":1}',
    '{\"id\":34,\"name\":\"ADMISIN 1\",\"description\":\"ADMISIN 1\",\"status\":1,\"id_floor\":1}',
    34,
    1,
    1
  ),(
    135,
    '2025-08-14 19:00:31',
    'areas',
    2,
    '{\"id\":42,\"name\":\"MEDICO RADIOLOGO\",\"description\":\"MEDICO RADIOLOGO\",\"status\":1,\"id_floor\":1}',
    '{\"id\":42,\"name\":\"MDICO RADIOLOGO\",\"description\":\"MDICO RADIOLOGO\",\"status\":1,\"id_floor\":1}',
    42,
    1,
    1
  ),(
    136,
    '2025-08-14 19:00:48',
    'areas',
    2,
    '{\"id\":46,\"name\":\"AUX ADMINISTRACION\",\"description\":\"AUX ADMINISTRACION\",\"status\":1,\"id_floor\":1}',
    '{\"id\":46,\"name\":\"AUX ADMINISTRACIN\",\"description\":\"AUX ADMINISTRACIN\",\"status\":1,\"id_floor\":1}',
    46,
    1,
    1
  ),(
    137,
    '2025-08-14 19:01:10',
    'areas',
    2,
    '{\"id\":45,\"name\":\"DIR ADMINISTRACION\",\"description\":\"DIR ADMINISTRACION\",\"status\":1,\"id_floor\":1}',
    '{\"id\":45,\"name\":\"DIR ADMINISTRACIN\",\"description\":\"DIR ADMINISTRACIN\",\"status\":1,\"id_floor\":1}',
    45,
    1,
    1
  ),(
    138,
    '2025-08-14 19:01:34',
    'areas',
    2,
    '{\"id\":38,\"name\":\"ENFERMERIA\",\"description\":\"ENFERMERIA\",\"status\":1,\"id_floor\":1}',
    '{\"id\":38,\"name\":\"ENFERMERA\",\"description\":\"ENFERMERA\",\"status\":1,\"id_floor\":1}',
    38,
    1,
    1
  ),(
    139,
    '2025-08-14 19:02:11',
    'areas',
    2,
    '{\"id\":38,\"name\":\"CENTRAL ENFERMERIA UREGNCIAS\",\"description\":\"ENFERMERIA\",\"status\":1,\"id_floor\":1}',
    '{\"id\":38,\"name\":\"ENFERMERIA\",\"description\":\"ENFERMERIA\",\"status\":1,\"id_floor\":1}',
    38,
    1,
    1
  ),(
    140,
    '2025-08-14 19:02:35',
    'areas',
    2,
    '{\"id\":57,\"name\":\"UTIA MEDICOS\",\"description\":\"UTIA MEDICOS\",\"status\":1,\"id_floor\":2}',
    '{\"id\":57,\"name\":\"UTIA MDICOS\",\"description\":\"UTIA MDICOS\",\"status\":1,\"id_floor\":2}',
    57,
    1,
    1
  ),(
    141,
    '2025-08-14 19:02:43',
    'areas',
    2,
    '{\"id\":55,\"name\":\"QX MEDICOS\",\"description\":\"QX MEDICOS\",\"status\":1,\"id_floor\":2}',
    '{\"id\":55,\"name\":\"QX MDICOS\",\"description\":\"QX MDICOS\",\"status\":1,\"id_floor\":2}',
    55,
    1,
    1
  ),(
    142,
    '2025-08-14 19:02:52',
    'areas',
    2,
    '{\"id\":54,\"name\":\"PROGRAMACION\",\"description\":\"PROGRAMACION\",\"status\":1,\"id_floor\":2}',
    '{\"id\":54,\"name\":\"PROGRAMACIN\",\"description\":\"PROGRAMACIN\",\"status\":1,\"id_floor\":2}',
    54,
    1,
    1
  ),(
    143,
    '2025-08-14 19:03:07',
    'areas',
    2,
    '{\"id\":50,\"name\":\"AUX CAPTURA 1\",\"description\":\"AUX CAPTURA 1\",\"status\":1,\"id_floor\":2}',
    '{\"id\":50,\"name\":\"AUXCAPTURA 1\",\"description\":\"AUXCAPTURA 1\",\"status\":1,\"id_floor\":2}',
    50,
    1,
    1
  ),(
    144,
    '2025-08-14 19:03:25',
    'areas',
    2,
    '{\"id\":56,\"name\":\"UTIA ENFERMERIA\",\"description\":\"UTIA ENFERMERIA\",\"status\":1,\"id_floor\":2}',
    '{\"id\":56,\"name\":\"UTIA ENFERMERA\",\"description\":\"UTIA ENFERMERA\",\"status\":1,\"id_floor\":2}',
    56,
    1,
    1
  ),(
    145,
    '2025-08-14 19:03:48',
    'areas',
    2,
    '{\"id\":60,\"name\":\"SUPERVISION ENFERMERIA\",\"description\":\"SUPERVISION ENFERMERIA\",\"status\":1,\"id_floor\":3}',
    '{\"id\":60,\"name\":\"SUPERVISIN ENFERMERIA\",\"description\":\"SUPERVISIN ENFERMERIA\",\"status\":1,\"id_floor\":3}',
    60,
    1,
    1
  ),(
    146,
    '2025-08-14 19:03:49',
    'responsivas',
    1,
    '{\"folio\":\"SIS-139\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":47,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[537]}',
    'null',
    6,
    1,
    1
  ),(
    147,
    '2025-08-14 19:04:05',
    'areas',
    2,
    '{\"id\":62,\"name\":\"DRA. CARMEN\",\"description\":\"CONTRALORÍA\",\"status\":1,\"id_floor\":3}',
    '{\"id\":62,\"name\":\"DRA.CARMEN\",\"description\":\"DRA.CARMEN\",\"status\":1,\"id_floor\":3}',
    62,
    1,
    1
  ),(
    148,
    '2025-08-14 19:04:24',
    'areas',
    2,
    '{\"id\":66,\"name\":\"CONSULTORIO MEDICO\",\"description\":\"CONSULTORIO MEDICO\",\"status\":1,\"id_floor\":3}',
    '{\"id\":66,\"name\":\"CONSULTORIO MDICO\",\"description\":\"CONSULTORIO MDICO\",\"status\":1,\"id_floor\":3}',
    66,
    1,
    1
  ),(
    149,
    '2025-08-14 19:05:24',
    'areas',
    2,
    '{\"id\":62,\"name\":\"CONTRALORÍA\",\"description\":\"CONTRALORÍA\",\"status\":1,\"id_floor\":3}',
    '{\"id\":62,\"name\":\"DRA. CARMEN\",\"description\":\"CONTRALORÍA\",\"status\":1,\"id_floor\":3}',
    62,
    1,
    1
  ),(
    150,
    '2025-08-14 19:05:43',
    'areas',
    2,
    '{\"id\":64,\"name\":\"DIRECCION GENERAL\",\"description\":\"DR. RUBEN\",\"status\":1,\"id_floor\":3}',
    '{\"id\":64,\"name\":\"DR. RUBEN\",\"description\":\"DR. RUBEN\",\"status\":1,\"id_floor\":3}',
    64,
    1,
    1
  ),(
    151,
    '2025-08-14 19:05:50',
    'areas',
    2,
    '{\"id\":62,\"name\":\"CONTRALORÍA\",\"description\":\"DRA. CARMEN\",\"status\":1,\"id_floor\":3}',
    '{\"id\":62,\"name\":\"CONTRALORÍA\",\"description\":\"CONTRALORÍA\",\"status\":1,\"id_floor\":3}',
    62,
    1,
    1
  ),(
    152,
    '2025-08-14 19:05:58',
    'areas',
    2,
    '{\"id\":63,\"name\":\"DIRECCION MEDICA\",\"description\":\"DR. GUILLEN\",\"status\":1,\"id_floor\":3}',
    '{\"id\":63,\"name\":\"DIRECCION MEDICA\",\"description\":\"DIRECCION MEDICA\",\"status\":1,\"id_floor\":3}',
    63,
    1,
    1
  ),(
    153,
    '2025-08-14 19:06:18',
    'areas',
    2,
    '{\"id\":82,\"name\":\"COO COMPRAS\",\"description\":\"COO COMPRAS\",\"status\":1,\"id_floor\":4}',
    '{\"id\":82,\"name\":\"COOCOMPRAS\",\"description\":\"COOCOMPRAS\",\"status\":1,\"id_floor\":4}',
    82,
    1,
    1
  ),(
    154,
    '2025-08-14 19:06:50',
    'areas',
    3,
    'null',
    '{\"id\":99,\"name\":\"BECARIO1\",\"description\":\"BECARIO1\",\"status\":1,\"id_floor\":6}',
    99,
    1,
    1
  ),(
    155,
    '2025-08-14 19:06:52',
    'areas',
    3,
    'null',
    '{\"id\":100,\"name\":\"BECARIO2\",\"description\":\"BECARIO2\",\"status\":1,\"id_floor\":6}',
    100,
    1,
    1
  ),(
    156,
    '2025-08-14 19:07:12',
    'areas',
    2,
    '{\"id\":98,\"name\":\"COOR MANTENIMIENTO\",\"description\":\"COOR MANTENIMIENTO\",\"status\":1,\"id_floor\":4}',
    '{\"id\":98,\"name\":\"COOR MANTENIMIENTO\",\"description\":\"COOR MANTENIMIENTO\",\"status\":1,\"id_floor\":6}',
    98,
    1,
    1
  ),(
    157,
    '2025-08-14 19:07:35',
    'areas',
    1,
    '{\"name\":\"MANTENIMIENTO\",\"description\":\"AUX. MANTENIMIENTO\",\"id_floor\":\"6\"}',
    'null',
    104,
    1,
    1
  ),(
    158,
    '2025-08-14 19:15:09',
    'areas',
    1,
    '{\"name\":\"PASILLO UTIA\",\"description\":\"Pasillo de UTIA y CEYE\",\"id_floor\":\"2\"}',
    'null',
    105,
    1,
    1
  ),(
    159,
    '2025-08-14 19:18:11',
    'responsivas',
    1,
    '{\"folio\":\"SIS-140\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":105,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[538]}',
    'null',
    7,
    1,
    1
  ),(
    160,
    '2025-08-14 19:27:32',
    'areas',
    1,
    '{\"name\":\"CENTRAL HOSPITALIZACION\",\"description\":\"CENTRAL DE MEDICOS DE HOSPITALIZACION PISO 2\",\"id_floor\":\"3\"}',
    'null',
    106,
    1,
    1
  ),(
    161,
    '2025-08-14 19:28:04',
    'responsivas',
    1,
    '{\"folio\":\"SIS-141\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":106,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[539]}',
    'null',
    8,
    1,
    1
  ),(
    162,
    '2025-08-14 19:29:54',
    'areas',
    1,
    '{\"name\":\"HOSPITALIZACION SUR\",\"description\":\"HOSPITALIZACION ALA SUR\",\"id_floor\":\"3\"}',
    'null',
    107,
    1,
    1
  ),(
    163,
    '2025-08-14 19:30:21',
    'areas',
    1,
    '{\"name\":\"HOSPITALIZACION NORTE\",\"description\":\"HOSPITALIZACION ALA NORTE\",\"id_floor\":\"3\"}',
    'null',
    108,
    1,
    1
  ),(
    164,
    '2025-08-14 19:31:42',
    'responsivas',
    1,
    '{\"folio\":\"SIS-142\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":107,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[541]}',
    'null',
    9,
    1,
    1
  ),(
    165,
    '2025-08-14 19:32:54',
    'responsivas',
    1,
    '{\"folio\":\"SIS-143\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":108,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[540]}',
    'null',
    10,
    1,
    1
  ),(
    166,
    '2025-08-14 19:34:40',
    'responsivas',
    1,
    '{\"folio\":\"SIS-144\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":96,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[542]}',
    'null',
    11,
    1,
    1
  ),(
    167,
    '2025-08-14 19:35:30',
    'areas',
    1,
    '{\"name\":\"GOBIERNO P3\",\"description\":\"GOBIERNO PISO 3\",\"id_floor\":\"4\"}',
    'null',
    109,
    1,
    1
  ),(
    168,
    '2025-08-14 19:36:47',
    'responsivas',
    1,
    '{\"folio\":\"SIS-145\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":109,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[543]}',
    'null',
    12,
    1,
    1
  ),(
    169,
    '2025-08-14 19:38:28',
    'areas',
    1,
    '{\"name\":\"CAPILLA\",\"description\":\"CAPILLA\",\"id_floor\":\"4\"}',
    'null',
    110,
    1,
    1
  ),(
    170,
    '2025-08-14 19:38:51',
    'responsivas',
    1,
    '{\"folio\":\"SIS-146\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":110,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[544]}',
    'null',
    13,
    1,
    1
  ),(
    171,
    '2025-08-14 19:40:27',
    'areas',
    1,
    '{\"name\":\"CHECADOR\",\"description\":\"ENTRADA DE EMPLEADOS\",\"id_floor\":\"1\"}',
    'null',
    111,
    1,
    1
  ),(
    172,
    '2025-08-14 19:40:55',
    'responsivas',
    1,
    '{\"folio\":\"SIS-147\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":111,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[545]}',
    'null',
    14,
    1,
    1
  ),(
    173,
    '2025-08-14 19:41:25',
    'responsivas',
    1,
    '{\"folio\":\"SIS-148\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":44,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[546]}',
    'null',
    15,
    1,
    1
  ),(
    174,
    '2025-08-14 19:42:08',
    'responsivas',
    1,
    '{\"folio\":\"SIS-149\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":39,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[547]}',
    'null',
    16,
    1,
    1
  ),(
    175,
    '2025-08-14 19:43:01',
    'areas',
    1,
    '{\"name\":\"SALON DE USOS MULTIPLES\",\"description\":\"SALA DE USOS MULTIPLES\",\"id_floor\":\"1\"}',
    'null',
    112,
    1,
    1
  ),(
    176,
    '2025-08-14 19:43:34',
    'responsivas',
    1,
    '{\"folio\":\"SIS-150\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":112,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[548]}',
    'null',
    17,
    1,
    1
  ),(
    177,
    '2025-08-14 19:44:03',
    'responsivas',
    1,
    '{\"folio\":\"SIS-151\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":104,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[549]}',
    'null',
    18,
    1,
    1
  ),(
    178,
    '2025-08-14 19:44:35',
    'areas',
    1,
    '{\"name\":\"BIOMEDICA\",\"description\":\"AREA DE BIOMEDICA\",\"id_floor\":\"1\"}',
    'null',
    113,
    1,
    1
  ),(
    179,
    '2025-08-14 19:45:04',
    'responsivas',
    1,
    '{\"folio\":\"SIS-152\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":113,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[550]}',
    'null',
    19,
    1,
    1
  ),(
    180,
    '2025-08-14 19:45:41',
    'areas',
    1,
    '{\"name\":\"SALA DE ESPERA P2\",\"description\":\"AREA FUERA DE HOSPITALIZACION\",\"id_floor\":\"3\"}',
    'null',
    114,
    1,
    1
  ),(
    181,
    '2025-08-14 19:46:15',
    'responsivas',
    1,
    '{\"folio\":\"SIS-153\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":114,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[551]}',
    'null',
    20,
    1,
    1
  ),(
    182,
    '2025-08-14 19:46:46',
    'responsivas',
    1,
    '{\"folio\":\"SIS-154\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":107,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[552]}',
    'null',
    21,
    1,
    1
  ),(
    183,
    '2025-08-14 19:47:29',
    'areas',
    1,
    '{\"name\":\"LOBBY\",\"description\":\"EMTRADA PRINCIPAL DEL HOSPITAL\",\"id_floor\":\"1\"}',
    'null',
    115,
    1,
    1
  ),(
    184,
    '2025-08-14 19:47:51',
    'responsivas',
    1,
    '{\"folio\":\"SIS-155\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":115,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[553]}',
    'null',
    22,
    1,
    1
  ),(
    185,
    '2025-08-14 19:48:16',
    'responsivas',
    1,
    '{\"folio\":\"SIS-156\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":108,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[554]}',
    'null',
    23,
    1,
    1
  ),(
    186,
    '2025-08-14 19:48:43',
    'responsivas',
    1,
    '{\"folio\":\"SIS-157\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":38,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[555]}',
    'null',
    24,
    1,
    1
  ),(
    187,
    '2025-08-14 19:49:14',
    'areas',
    1,
    '{\"name\":\"GOBIERNO\",\"description\":\"GOBIERNO PISO 2\",\"id_floor\":\"3\"}',
    'null',
    116,
    1,
    1
  ),(
    188,
    '2025-08-14 19:49:37',
    'responsivas',
    1,
    '{\"folio\":\"SIS-158\",\"fecha\":\"2025-08-14\",\"responsable\":\"SISTEMAS\",\"id_area\":116,\"id_departamento\":34,\"user_id\":1,\"dispositivos\":[556]}',
    'null',
    25,
    1,
    1
  ),(
    189,
    '2026-01-29 20:35:02',
    'mantenimientos',
    1,
    '{\"id\":1,\"folio\":\"MAN-141\",\"fecha\":\"2026-01-29\",\"descripcion_falla\":\"\",\"descripcion_solucion\":\"\",\"user_id\":1,\"responsiva_id\":16,\"completo\":1}',
    'null',
    1,
    1,
    1
  ),(
    191,
    '2026-01-29 22:22:19',
    'users',
    4,
    '{}',
    '{\"id\":3,\"username\":\"Ivonne\",\"status\":1}',
    3,
    1,
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: passwords
# ------------------------------------------------------------

INSERT INTO
  `passwords` (`id`, `password_hash`)
VALUES
  (
    1,
    '$2b$10$VwlnvETKqe5jWV30Jln65OysZytb4MuLrmkq6otKCsl6Ve3jR..u2'
  ),(
    2,
    '$2b$10$t9mAiynMZaYdWM.6OBtGg.p/CEAVa1IFi3Dn9QwR9nMrOLRf0SRry'
  ),(
    3,
    '$2b$10$ZlRUIlTK4ibzwvTdFTbEYe/aA7OeA0g1lrNoxi6ElcSYkASiNy0FS'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: responsiva_documentos
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: responsiva_equipos
# ------------------------------------------------------------

INSERT INTO
  `responsiva_equipos` (`id`, `id_responsiva`, `id_device`)
VALUES
  (2, 1, 2),(1, 1, 532),(3, 2, 259),(5, 3, 268),(4, 3, 533),(7, 4, 253),(6, 4, 535),(8, 5, 536),(9, 6, 537),(10, 7, 538),(11, 8, 539),(12, 9, 541),(13, 10, 540),(14, 11, 542),(15, 12, 543),(16, 13, 544),(17, 14, 545),(18, 15, 546),(19, 16, 547),(20, 17, 548),(21, 18, 549),(22, 19, 550),(23, 20, 551),(24, 21, 552),(25, 22, 553),(26, 23, 554),(27, 24, 555),(28, 25, 556);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: responsivas
# ------------------------------------------------------------

INSERT INTO
  `responsivas` (
    `id`,
    `folio`,
    `fecha`,
    `responsable`,
    `id_area`,
    `id_departamento`,
    `user_id`,
    `status`
  )
VALUES
  (
    1,
    'SIS-134',
    '2025-08-08',
    'Brayham Pavon Martell',
    88,
    34,
    1,
    1
  ),(
    2,
    'SIS-135',
    '2025-08-08',
    'Jesus Antonio Chavez Fabian ',
    86,
    34,
    1,
    1
  ),(
    3,
    'SIS-136',
    '2025-08-08',
    'Juan Carlos Monroy',
    85,
    34,
    1,
    1
  ),(
    4,
    'SIS-137',
    '2025-08-08',
    'Juan Carlos Monroy',
    102,
    34,
    1,
    1
  ),(5, 'SIS-138', '2025-08-14', 'SISTEMAS', 103, 34, 1, 1),(6, 'SIS-139', '2025-08-14', 'SISTEMAS', 47, 34, 1, 1),(7, 'SIS-140', '2025-08-14', 'SISTEMAS', 105, 34, 1, 1),(8, 'SIS-141', '2025-08-14', 'SISTEMAS', 106, 34, 1, 1),(9, 'SIS-142', '2025-08-14', 'SISTEMAS', 107, 34, 1, 1),(10, 'SIS-143', '2025-08-14', 'SISTEMAS', 108, 34, 1, 1),(11, 'SIS-144', '2025-08-14', 'SISTEMAS', 96, 34, 1, 1),(12, 'SIS-145', '2025-08-14', 'SISTEMAS', 109, 34, 1, 1),(13, 'SIS-146', '2025-08-14', 'SISTEMAS', 110, 34, 1, 1),(14, 'SIS-147', '2025-08-14', 'SISTEMAS', 111, 34, 1, 1),(15, 'SIS-148', '2025-08-14', 'SISTEMAS', 44, 34, 1, 1),(16, 'SIS-149', '2025-08-14', 'SISTEMAS', 39, 34, 1, 1),(17, 'SIS-150', '2025-08-14', 'SISTEMAS', 112, 34, 1, 1),(18, 'SIS-151', '2025-08-14', 'SISTEMAS', 104, 34, 1, 1),(19, 'SIS-152', '2025-08-14', 'SISTEMAS', 113, 34, 1, 1),(20, 'SIS-153', '2025-08-14', 'SISTEMAS', 114, 34, 1, 1),(21, 'SIS-154', '2025-08-14', 'SISTEMAS', 107, 34, 1, 1),(22, 'SIS-155', '2025-08-14', 'SISTEMAS', 115, 34, 1, 1),(23, 'SIS-156', '2025-08-14', 'SISTEMAS', 108, 34, 1, 1),(24, 'SIS-157', '2025-08-14', 'SISTEMAS', 38, 34, 1, 1),(25, 'SIS-158', '2025-08-14', 'SISTEMAS', 116, 34, 1, 1);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: users
# ------------------------------------------------------------

INSERT INTO
  `users` (
    `id`,
    `name`,
    `last_name`,
    `username`,
    `role`,
    `password_id`,
    `status`
  )
VALUES
  (1, 'ADMIN', 'ADMiN', 'Admin', 1, 1, 1),(2, 'Brayham', 'Pavon Martell', 'pmbrian', 1, 2, 1);

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
